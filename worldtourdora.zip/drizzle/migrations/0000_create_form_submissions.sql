CREATE TABLE public.form_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  form_type TEXT NOT NULL CHECK (char_length(form_type) BETWEEN 1 AND 60),
  role TEXT CHECK (role IS NULL OR char_length(role) <= 60),
  name TEXT CHECK (name IS NULL OR char_length(name) <= 100),
  email TEXT CHECK (email IS NULL OR char_length(email) <= 255),
  city TEXT CHECK (city IS NULL OR char_length(city) <= 120),
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.form_submissions TO service_role;
ALTER TABLE public.form_submissions ENABLE ROW LEVEL SECURITY;
CREATE INDEX form_submissions_created_at_idx ON public.form_submissions (created_at DESC);
CREATE INDEX form_submissions_form_type_idx ON public.form_submissions (form_type);