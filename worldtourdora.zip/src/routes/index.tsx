import { ClientOnly, createFileRoute, Link } from "@tanstack/react-router";
import { lazy, type ReactNode } from "react";
import { ArrowRight, Bike, MessageCircle } from "lucide-react";
import { PageFrame } from "@/components/dora-layout";
import { JoinJourney } from "@/components/join-journey";
import { TourPhones } from "@/components/tour-phones";
import { AudienceSection } from "@/components/audience-section";
import { PartnerShowcase } from "@/components/partner-showcase";
import { Chapter, WhatHappens, CityLifecycle, TourTakingShape, FinalCta } from "@/components/home-story";
import { Button } from "@/components/ui/button";
import { HomeFaqInvite } from "@/components/home-faq-invite";
import referenceHero from "@/assets/dora-reference-hero-final.png";
import gathering from "@/assets/dora-gathering.jpg";
import tourLogo from "@/assets/world-tour-ft-dora-logo.svg.asset.json";

const TourMapSection = lazy(() => import("@/components/tour-map-section").then((module) => ({ default: module.TourMapSection })));

export const Route=createFileRoute("/")({head:()=>({meta:[{title:"DoraDAO World Tour — Ready again to be human"},{name:"description",content:"People × Community × Impact. A city-by-city movement bringing people back to each other."},{property:"og:title",content:"DoraDAO World Tour — Ready again to be human"},{property:"og:description",content:"A global community on the move."},{property:"og:type",content:"website"},{name:"twitter:card",content:"summary_large_image"}],links:[{rel:"canonical",href:"/"}]}),component:Home});

function Home(){return <PageFrame>
  <CampaignHero/>
  <Why/>
  <WhatHappens/>
  <PillarStory/>
  <TourMap/>
  <CityLifecycle/>
  <AudienceSection/>
  <PartnerShowcase/>
  <TourTakingShape/>
  <HomeFaqInvite/>
  <FinalCta/>
</PageFrame>}

function CampaignHero(){return <section className="campaign-hero">
  <div className="campaign-hero-scene">
    <img src={referenceHero} alt="Dora and a white cat sitting on a colorful globe between tropical foliage and a European hillside town" width={1584} height={672} fetchPriority="high" className="campaign-hero-art"/>
    <div className="campaign-hero-title">
      <h1><img src={tourLogo.url} alt="World Tour featuring Dora" className="campaign-hero-logo" /></h1>
    </div>
    <div className="campaign-hero-note">
      <p className="font-hand text-2xl leading-none text-ink">New places.<br/>New faces.<br/>Bigger dreams. ♡</p>
    </div>
    <div className="campaign-hero-copy">
      <p className="font-hand text-[1.9rem] font-bold leading-none text-ink sm:text-4xl">Ready again to be human.</p>
      <p className="mt-3 max-w-sm text-sm font-semibold leading-6 text-ink/85">A global movement of local gatherings — helping people meet, learn, create, contribute and belong in real life.</p>
      <p className="mt-2 hidden max-w-sm text-sm leading-6 text-ink/75 lg:block">Dora goes city to city. Local people turn each stop into something of their own.</p>
      <div className="mt-4 flex flex-wrap justify-center gap-3 sm:justify-end lg:justify-start">
        <JoinJourney><Button className="rounded-full px-6">Find your way in <ArrowRight/></Button></JoinJourney>
        <JoinJourney defaultRole="city"><Button variant="secondary" className="rounded-full px-6">Bring Dora to my city</Button></JoinJourney>
      </div>
      <p className="mt-3 text-xs font-bold uppercase tracking-widest text-ink/70">A DoraDAO initiative.</p>
    </div>
  </div>
</section>}

function Why(){return <section className="why-editorial paper-texture" aria-labelledby="why-title"><div className="why-grid" aria-hidden="true"/><div className="home-shell relative py-10 sm:py-12 lg:py-16"><div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-5"><Chapter number="02" label="Why we're here"/><p className="hidden font-hand text-xl text-coral sm:block">A note on being together ↘</p></div><h2 id="why-title" className="home-heading mt-6 max-w-4xl">We got really good at being connected.</h2><div className="why-manifesto mt-7 sm:mt-9">
  <p><span className="why-ink">Somewhere along the way, we got <strong>REALLY</strong> good at being connected…</span> and somehow, really bad at actually being together. <InlineSymbol label="Messages all day" motion="drift"><MessageCircle/></InlineSymbol> We have hundreds of people in our phones, conversations happening all day, group chats that never really sleep, feeds that never end, and a thousand little ways to meet someone. <span className="why-soft">And still, every once in a while, there’s that quiet little feeling that catches you in the middle of a completely ordinary day:</span> <em>“I wish I had my people here.”</em></p>
  <p><span className="why-soft">Because</span> <strong>your people</strong> are different. They’re the ones you can randomly call without needing a reason. The ones you can drag into a stupid little walk at 11 PM <InlineSymbol label="A walk with your people" motion="roll"><Bike/></InlineSymbol> and somehow come back three hours later having talked about childhood, heartbreak, money, dreams, the weirdest thing you saw that morning, and <strong>everything in between.</strong> They’re the ones you meet for the first time and, somehow, within twenty minutes, you’re laughing like you’ve known each other forever. The ones who make a new city feel a little less unfamiliar. The ones who make you feel seen without having to explain yourself too much. <span className="why-soft">And honestly,</span> we miss that.</p>
  <p>We <strong>MISS</strong> the electricity of meeting someone new. <InlinePhoto/> We miss discovering a place because someone said, <em>“Come, I know somewhere.”</em> We miss sitting around a table until the food is cold because nobody wants to leave yet. We miss laughing way too loudly with people who were strangers an hour ago and somehow aren’t anymore. We miss learning something from someone who sees the world completely differently. We miss making things with our hands, getting lost on a trail, painting something terribly, cooking for too many people, starting a conversation that goes somewhere none of us expected. We miss saying <em>“why not?”</em> and actually meaning it.</p>
  <p><span className="why-soft">Because life, at its best, is supposed to feel a little more like this.</span> You wake up, you go somewhere, you meet someone, you try something, you laugh, you get surprised, you care, you make a memory you didn’t plan for. You actually <strong>LIVE</strong> it. <span className="why-soft">Not just document it. Not just post it. Not just tell yourself you’ll do it someday.</span></p>
  <p>And we don’t think that feeling of belonging should be something you accidentally stumble into once in a while. It should be something you get to experience again and again and <strong>AGAIN.</strong> <span className="why-soft">That’s why we’re taking Dora on a</span> <span className="why-accent">World Tour.</span></p>
  <p><span className="why-soft">And just so we’re clear about who’s who,</span> <strong>Dora</strong> is the little traveler carrying the spirit of this idea, <strong>DoraDAO</strong> is the community of humans behind it, and the <strong>World Tour</strong> is what happens when we take that spirit off the screen and into the real world. Into cities, rooms, tables, trails, classrooms, parks, studios, neighbourhoods and wherever people decide they want to gather.</p>
  <p><span className="why-ink">Not to host another conference.</span> Not to create another thing you attend, take a picture at, tag three people in and forget by next Tuesday. We’re going city to city to create little pockets of <strong>HUMAN</strong> connection. Dinners. Walks. Workshops. Adventures. Art. Conversations. Causes. Skill swaps. Strange little ideas. New friendships. Old friendships. Unexpected collaborations. <span className="why-soft">And all the beautiful, slightly chaotic things that happen when people stop watching life from the outside and actually step into it together.</span></p>
  <p>Because maybe the world doesn’t need more ways to keep us connected. Maybe it needs more reasons to bring us <strong>TOGETHER.</strong> Maybe we need more excuses to leave the house, walk into a room where we don’t know anyone, sit beside someone, look them in the eyes and say, <em>“Hi, I’m glad you’re here.”</em></p>
  <p><span className="why-soft">And if you’ve ever felt that too, if you’ve ever wished your city felt a little more alive, if you’ve ever wanted to find your people or become someone’s people, if you’ve ever wanted to make something happen simply because it would make life feel a little more beautiful,</span> yeah. <em>You’re exactly who we’re doing this for.</em></p>
  <p className="why-closing">Because being around people isn’t the same as <strong>belonging to people.</strong> <span className="why-soft">And we want to build a world where belonging doesn’t have to be something you hope you’ll find.</span></p>
</div><p className="story-spark mx-auto max-w-4xl text-center">You can make it. You can find it. You can give it to someone else. And you can come back to it, <strong>again and again.</strong></p><div className="mt-7 flex items-center justify-between gap-5 border-t-2 border-ink/15 pt-4"><p className="font-hand text-xl text-coral sm:text-2xl">So… here's how it actually works ↓</p></div></div></section>}

function InlineSymbol({children,label,motion}:{children:ReactNode;label:string;motion:"drift"|"roll"}){return <span className={`why-symbol why-symbol-${motion}`} role="img" aria-label={label}>{children}</span>}

function InlinePhoto(){return <span className="why-photo"><img src={gathering} alt="People sharing a meal together" width={1200} height={1500} loading="lazy"/><span aria-hidden="true">show up</span></span>}

function PillarStory(){return <section className="tour-phones-section"><div className="home-shell"><Chapter number="04" label="Five ways to belong"/><div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr] lg:items-end"><h2 className="home-heading">Five ways to belong.</h2><p className="max-w-xl text-lg leading-7">Not event categories — five reasons to show up. I want to meet people. Learn something. Give back. Experience something. Make something. Open one.</p></div><TourPhones/><ClosingNote/></div></section>}

function ClosingNote(){return <div className="phones-closing" aria-labelledby="closing-title">
  <p className="phones-closing-badge"><span>100+</span><strong>And counting</strong></p>
  <h3 id="closing-title" className="phones-closing-title">Don't see your thing yet?</h3>
  <p className="phones-closing-copy">Long Table, Failure School, Sunrise Missions — those are just five examples out of 100+ activities across these five ways in, and more get added every week. If yours isn't on the list yet, that usually just means nobody's tried it yet.</p>
  <div className="phones-closing-actions">
    <JoinJourney><Button variant="outline" className="rounded-full">Apply to attend</Button></JoinJourney>
    <JoinJourney defaultRole="host"><Button variant="outline" className="rounded-full">Apply to host</Button></JoinJourney>
    <JoinJourney defaultRole="support"><Button variant="outline" className="rounded-full">Apply to sponsor</Button></JoinJourney>
    <JoinJourney defaultRole="collaborate"><Button variant="outline" className="rounded-full">Apply to partner</Button></JoinJourney>
  </div>
</div>}

function TourMap(){return <ClientOnly fallback={<section className="where-dora-section"><div className="home-shell"><div className="h-[32rem] animate-pulse rounded-lg bg-muted"/></div></section>}><TourMapSection/></ClientOnly>}

