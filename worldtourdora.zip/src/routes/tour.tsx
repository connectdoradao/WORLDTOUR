import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, Radio } from "lucide-react";
import { PageFrame, SectionHeading } from "@/components/dora-layout";
import { CityCard, StatusBadge, WorldMap } from "@/components/dora-cards";
import { Button } from "@/components/ui/button";
import { cities, statusLabels, type CityStatus } from "@/lib/dora-data";

export const Route = createFileRoute("/tour")({
  head: () => ({
    meta: [
      { title: "The Tour — Dora World Tour" },
      { name: "description", content: "Follow Dora World Tour from live stops to upcoming cities and stories from the road." },
      { property: "og:title", content: "The Tour — Dora World Tour" },
      { property: "og:description", content: "A living atlas of where Dora is now, where the tour is going, and where it has been." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/tour" }],
  }),
  component: TourPage,
});

const live = cities.filter((city) => city.status === "confirmed");
const upcoming = cities.filter((city) => city.status === "coming-soon");
const past = cities.filter((city) => city.status === "past");

function TourPage() {
  return <PageFrame>
    <section className="chapter-band bg-deep-blue text-paper">
      <div className="mx-auto grid min-h-[min(44rem,calc(100svh-4rem))] max-w-7xl content-between gap-12 px-5 py-10 lg:px-8 lg:py-14">
        <div className="flex items-center justify-between gap-6 border-b border-paper/20 pb-5 text-xs font-bold uppercase">
          <span>Field guide 01</span><span className="font-hand text-xl normal-case text-sun">The world is the venue.</span>
        </div>
        <div className="grid gap-8 lg:grid-cols-[1.25fr_.75fr] lg:items-end">
          <h1 className="max-w-4xl text-balance font-poster text-[clamp(3.2rem,9vw,7.5rem)] leading-[.88]">One tour.<br/><span className="text-sun">Many ways in.</span></h1>
          <div className="lg:pb-3"><p className="max-w-md text-lg leading-8">Follow the live stop, see which cities are gathering momentum, or open the archive of places that shaped the journey.</p><Button asChild variant="secondary" className="mt-7 rounded-full"><Link to="/request-city">Put your city on the map <ArrowRight/></Link></Button></div>
        </div>
      </div>
    </section>

    <section className="interior-canvas editorial-section">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mb-9 grid gap-6 lg:grid-cols-[1fr_auto] lg:items-end"><SectionHeading eyebrow="The living atlas" title="Where Dora is." copy="Select a marker to move through live, upcoming, requested, and past stops."/><StatusLegend/></div>
        <WorldMap/>
      </div>
    </section>

    <section className="chapter-band bg-sun/35">
      <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8 lg:py-20">
        <div className="grid gap-10 lg:grid-cols-[.7fr_1.3fr]">
          <div><p className="campaign-kicker">Live now</p><h2 className="mt-3 font-poster text-4xl leading-none sm:text-5xl">The room is open.</h2><p className="mt-5 max-w-md leading-7">Confirmed schedules shown here are prototype content pending verification.</p></div>
          <div className="space-y-5">{live.map(city => <LiveStop key={city.id} city={city}/>)}</div>
        </div>
      </div>
    </section>

    <section className="editorial-section bg-paper">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-5"><SectionHeading eyebrow="Next on the route" title="Upcoming stops." copy="Cities gathering names and local energy before a stop is confirmed."/><Button asChild variant="outline" className="rounded-full"><Link to="/cities">Open city directory <ArrowRight/></Link></Button></div>
        <div className="mt-10 grid gap-7 md:grid-cols-3">{upcoming.map(city => <CityCard key={city.id} city={city}/>)}</div>
      </div>
    </section>

    <section className="chapter-band bg-coral text-paper">
      <div className="mx-auto grid max-w-7xl gap-8 px-5 py-14 lg:grid-cols-[1fr_auto] lg:items-end lg:px-8 lg:py-20"><div><p className="font-hand text-2xl text-sun">The route keeps its memories.</p><h2 className="mt-3 max-w-4xl font-poster text-4xl leading-none sm:text-6xl">Every past stop becomes part of the archive.</h2><p className="mt-5 max-w-2xl leading-7">{past.length} prototype city stories currently shape this preview. Dates and outcomes remain clearly marked until verified.</p></div><Button asChild variant="secondary" className="rounded-full"><Link to="/past-stops">Visit past stops <ArrowRight/></Link></Button></div>
    </section>
  </PageFrame>;
}

function LiveStop({ city }: { city: (typeof cities)[number] }) {
  return <article className="grid overflow-hidden border-2 border-ink/15 bg-paper shadow-[7px_8px_0_var(--deep-blue)] sm:grid-cols-[12rem_minmax(0,1fr)_auto] sm:items-center"><img src={city.heroImage} alt={`${city.name}, ${city.country}`} className="h-52 w-full object-cover sm:h-full"/><div className="p-5"><StatusBadge city={city}/><h3 className="mt-2 font-poster text-3xl text-deep-blue">{city.name}</h3><p className="mt-2 text-sm text-muted-foreground"><MapPin className="mr-1 inline size-4"/>{city.country} · {city.dates}</p></div><Button asChild className="m-5 rounded-full"><Link to="/cities/$citySlug" params={{citySlug:city.slug}}>Open stop <ArrowRight/></Link></Button></article>;
}

function StatusLegend() {
  const order: CityStatus[] = ["confirmed", "coming-soon", "requested", "past"];
  return <div className="flex max-w-full flex-wrap gap-x-4 gap-y-2 text-xs font-bold uppercase" aria-label="City status legend">{order.map(status => <span key={status} className="inline-flex items-center gap-2"><Radio className="size-3 text-coral"/>{statusLabels[status]}</span>)}</div>;
}