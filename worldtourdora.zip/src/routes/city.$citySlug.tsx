import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/city/$citySlug")({
  beforeLoad: ({ params }) => { throw redirect({ to: "/cities/$citySlug", params: { citySlug: params.citySlug } }); },
});