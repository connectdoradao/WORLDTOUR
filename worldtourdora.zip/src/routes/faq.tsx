import { createFileRoute } from "@tanstack/react-router";
import { PageFrame } from "@/components/dora-layout";
import { FaqSection } from "@/components/faq-section";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ — Dora World Tour" },
      { name: "description", content: "Straight answers about attending, hosting, partnering with, and staying safe at Dora World Tour." },
      { property: "og:title", content: "FAQ — Dora World Tour" },
      { property: "og:description", content: "Everything first-timers, hosts, partners, and curious people ask about Dora World Tour." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/faq" }],
  }),
  component: FaqPage,
});

function FaqPage() {
  return <PageFrame>
    <section className="faq-page paper-texture" aria-labelledby="faq-title">
      <div className="home-shell">
        <header className="faq-intro">
          <p className="campaign-kicker">Questions people actually ask</p>
          <h1 id="faq-title">Before you show up, here's everything.</h1>
          <p>Whoever you are — first-timer, host, partner, or just curious — these are the questions we hear most, answered straight. And yes, some of this happens online too — the tour is built to reach every timezone, not just the cities we've physically landed in.</p>
        </header>
        <FaqSection />
      </div>
    </section>
  </PageFrame>;
}
