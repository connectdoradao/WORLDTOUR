import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CalendarDays, ExternalLink, MapPin, Search, Tag, Ticket, User, X } from "lucide-react";
import { PageFrame } from "@/components/dora-layout";
import { JoinJourney } from "@/components/join-journey";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { allEventTags, eventCategories, ticketLabels, tourEvents, type TourEvent } from "@/lib/tour-events";

export const Route = createFileRoute("/cities/")({
  head: () => ({
    meta: [
      { title: "Tour events by city — Dora World Tour" },
      { name: "description", content: "Every confirmed Dora World Tour event, city by city — what happens, what to expect, and how to join." },
      { property: "og:title", content: "Tour events by city — Dora World Tour" },
      { property: "og:description", content: "Every confirmed Dora World Tour event, city by city — what happens, what to expect, and how to join." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/cities" }],
  }),
  component: CitiesPage,
});

function CitiesPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [ticket, setTicket] = useState("all");
  const [continent, setContinent] = useState("all");
  const [activeTags, setActiveTags] = useState<string[]>([]);

  const continents = useMemo(() => Array.from(new Set(tourEvents.map((e) => e.continent))).sort(), []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return tourEvents.filter((event) => {
      if (category !== "all" && event.category !== category) return false;
      if (ticket !== "all" && event.ticket !== ticket) return false;
      if (continent !== "all" && event.continent !== continent) return false;
      if (activeTags.length && !activeTags.every((t) => event.tags.includes(t))) return false;
      if (!q) return true;
      const haystack = [event.name, event.city, event.country, event.type, event.description, event.category, ...event.tags]
        .join(" ")
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [search, category, ticket, continent, activeTags]);

  const toggleTag = (tag: string) =>
    setActiveTags((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));

  return (
    <PageFrame>
      <section className="interior-canvas editorial-section">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-[1fr_auto] lg:items-end">
            <div>
              <p className="campaign-kicker">Where Dora is going</p>
              <h1 className="campaign-title mt-3 text-deep-blue">Every stop, every gathering.</h1>
              <p className="mt-4 max-w-xl text-lg leading-7">
                The confirmed events on the tour so far — what happens, what to expect, and how to
                join. More appear as hosts are approved.
              </p>
            </div>
            <div className="hidden rotate-2 items-center gap-3 border-2 border-coral bg-paper px-5 py-3 font-hand text-xl lg:flex">
              <MapPin className="text-coral" /> New places. Same human energy.
            </div>
          </div>

          <div className="scrapbook-frame mt-9 grid gap-4 p-5 sm:grid-cols-2 xl:grid-cols-[1fr_auto_auto_auto]">
            <label className="relative sm:col-span-2 xl:col-span-1">
              <span className="sr-only">Search events</span>
              <Search className="absolute left-3 top-3 size-5 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search events, cities, tags..."
                className="h-11 bg-paper pl-10"
              />
            </label>
            <Filter label="Category" value={category} set={setCategory} options={["all", ...eventCategories]} />
            <Filter label="Tickets" value={ticket} set={setTicket} options={["all", "free", "paid", "sponsored"]} />
            <Filter label="Continent" value={continent} set={setContinent} options={["all", ...continents]} />
          </div>

          <div className="mt-5 flex flex-wrap items-center gap-2" aria-label="Filter by tag">
            <span className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wide text-muted-foreground">
              <Tag className="size-3.5" /> Tags
            </span>
            {allEventTags.map((tag) => {
              const active = activeTags.includes(tag);
              return (
                <button
                  key={tag}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  aria-pressed={active}
                  className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                    active
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-dashed border-input bg-paper hover:border-primary"
                  }`}
                >
                  {tag}
                </button>
              );
            })}
            {activeTags.length > 0 && (
              <button
                type="button"
                onClick={() => setActiveTags([])}
                className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-semibold text-coral hover:underline"
              >
                <X className="size-3" /> Clear
              </button>
            )}
          </div>

          <p className="mt-6 font-hand text-xl text-coral" aria-live="polite">
            {filtered.length} {filtered.length === 1 ? "event" : "events"} on this page
          </p>

          <div className="mt-5 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((event) => (
              <EventCard key={event.id} event={event} onTag={toggleTag} />
            ))}
          </div>
          {!filtered.length && (
            <p className="py-20 text-center font-display text-3xl">No events match those filters yet.</p>
          )}
        </div>
      </section>
    </PageFrame>
  );
}

function EventCard({ event, onTag }: { event: TourEvent; onTag: (tag: string) => void }) {
  return (
    <article className="group scrapbook-frame flex flex-col overflow-hidden transition-transform duration-300 odd:-rotate-[.35deg] even:rotate-[.35deg] hover:rotate-0">
      <div className="border-b ink-rule p-5 pb-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-wide text-coral">{event.category} · {event.type}</p>
            <h3 className="mt-1 font-poster text-2xl leading-tight">{event.name}</h3>
            <p className="mt-1 inline-flex items-center gap-1 text-sm text-muted-foreground">
              <MapPin className="size-3.5" /> {event.city}, {event.country}
            </p>
          </div>
          <span className="shrink-0 rounded-full border border-input bg-paper px-2.5 py-1 text-xs font-bold uppercase">
            {ticketLabels[event.ticket]}
          </span>
        </div>
        <p className="mt-3 text-sm leading-6">{event.description}</p>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5 pt-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">What to expect</p>
          <ul className="mt-2 space-y-1.5 text-sm leading-6">
            {event.expect.map((item) => (
              <li key={item} className="flex gap-2">
                <span aria-hidden="true" className="mt-2 size-1.5 shrink-0 rounded-full bg-coral" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {event.tags.map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => onTag(tag)}
              className="rounded-full border border-dashed border-input bg-paper px-2 py-0.5 text-[11px] font-semibold hover:border-primary"
            >
              {tag}
            </button>
          ))}
        </div>

        <div className="mt-auto space-y-2 border-t ink-rule pt-4 text-xs">
          <p className="inline-flex items-center gap-1.5">
            <CalendarDays className="size-3.5 text-coral" /> {event.date}
          </p>
          <p className="flex items-center gap-1.5">
            <User className="size-3.5 text-coral" /> Hosted by {event.host}
          </p>
          {event.hostSocials.length > 0 && (
            <p className="flex flex-wrap gap-2">
              {event.hostSocials.map((social) => (
                <a key={social.href} href={social.href} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold hover:underline">
                  {social.label} <ExternalLink className="size-3" />
                </a>
              ))}
            </p>
          )}
          {event.eventLink && (
            <a href={event.eventLink} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 font-semibold hover:underline">
              Event page <ExternalLink className="size-3" />
            </a>
          )}
        </div>

        <JoinJourney defaultRole="experience">
          <Button className="w-full rounded-full">
            <Ticket className="size-4" /> Join this event
          </Button>
        </JoinJourney>
      </div>
    </article>
  );
}

function Filter({ label, value, set, options }: { label: string; value: string; set: (v: string) => void; options: readonly string[] }) {
  return (
    <label className="grid gap-1 text-xs font-bold uppercase">
      <span>{label}</span>
      <select
        value={value}
        onChange={(e) => set(e.target.value)}
        className="h-11 w-full min-w-0 border-0 border-b-2 border-input bg-paper px-2 text-sm font-normal normal-case focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        {options.map((o) => (
          <option value={o} key={o}>
            {o === "all" ? "All" : o.charAt(0).toUpperCase() + o.slice(1)}
          </option>
        ))}
      </select>
    </label>
  );
}
