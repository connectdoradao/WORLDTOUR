import accenture from "@/assets/partner-logos/accenture.webp.asset.json";
import adobe from "@/assets/partner-logos/adobe.webp.asset.json";
import amazon from "@/assets/partner-logos/amazon.webp.asset.json";
import americanExpress from "@/assets/partner-logos/american-express.webp.asset.json";
import apple from "@/assets/partner-logos/apple.webp.asset.json";
import autodesk from "@/assets/partner-logos/autodesk.png.asset.json";
import blinkit from "@/assets/partner-logos/blinkit.webp.asset.json";
import cambridge from "@/assets/partner-logos/cambridge.webp.asset.json";
import cloudEagle from "@/assets/partner-logos/cloudeagle.png.asset.json";
import deloitte from "@/assets/partner-logos/deloitte.webp.asset.json";
import disney from "@/assets/partner-logos/disney.webp.asset.json";
import dodoPayments from "@/assets/partner-logos/dodo-payments.png.asset.json";
import ethZurich from "@/assets/partner-logos/eth-zurich.webp.asset.json";
import flipkart from "@/assets/partner-logos/flipkart.webp.asset.json";
import google from "@/assets/partner-logos/google.webp.asset.json";
import growthX from "@/assets/partner-logos/growthx.png.asset.json";
import harvard from "@/assets/partner-logos/harvard.webp.asset.json";
import iitBombay from "@/assets/partner-logos/iit-bombay.webp.asset.json";
import iitKanpur from "@/assets/partner-logos/iit-kanpur.webp.asset.json";
import iitRoorkee from "@/assets/partner-logos/iit-roorkee.webp.asset.json";
import illinoisChicago from "@/assets/partner-logos/illinois-chicago.webp.asset.json";
import imperialCollege from "@/assets/partner-logos/imperial-college-london.webp.asset.json";
import jioStar from "@/assets/partner-logos/jiostar.webp.asset.json";
import medfin from "@/assets/partner-logos/medfin.png.asset.json";
import meta from "@/assets/partner-logos/meta.webp.asset.json";
import miro from "@/assets/partner-logos/miro.png.asset.json";
import microsoft from "@/assets/partner-logos/microsoft.webp.asset.json";
import mit from "@/assets/partner-logos/mit.webp.asset.json";
import morganStanley from "@/assets/partner-logos/morgan-stanley.webp.asset.json";
import neuralArc from "@/assets/partner-logos/neuralarc.png.asset.json";
import nvidia from "@/assets/partner-logos/nvidia.webp.asset.json";
import openAi from "@/assets/partner-logos/openai.webp.asset.json";
import oracle from "@/assets/partner-logos/oracle.webp.asset.json";
import oxford from "@/assets/partner-logos/oxford.webp.asset.json";
import paperflite from "@/assets/partner-logos/paperflite.png.asset.json";
import render from "@/assets/partner-logos/render.png.asset.json";
import salesforce from "@/assets/partner-logos/salesforce.webp.asset.json";
import samsung from "@/assets/partner-logos/samsung.webp.asset.json";
import skoob from "@/assets/partner-logos/skoob.png.asset.json";
import sprinklr from "@/assets/partner-logos/sprinklr.png.asset.json";
import stanford from "@/assets/partner-logos/stanford.webp.asset.json";
import tii from "@/assets/partner-logos/tii.png.asset.json";
import visa from "@/assets/partner-logos/visa.webp.asset.json";
import xyz from "@/assets/partner-logos/xyz.png.asset.json";
import zomato from "@/assets/partner-logos/zomato.webp.asset.json";

const organizations = [
  { name: "Google", logo: google.url },
  { name: "Amazon", logo: amazon.url },
  { name: "Microsoft", logo: microsoft.url },
  { name: "Disney", logo: disney.url },
  { name: "Meta", logo: meta.url },
  { name: "Zomato", logo: zomato.url },
  { name: "Flipkart", logo: flipkart.url },
  { name: "Apple", logo: apple.url },
  { name: "Adobe", logo: adobe.url },
  { name: "Samsung", logo: samsung.url },
  { name: "Blinkit", logo: blinkit.url },
  { name: "NVIDIA", logo: nvidia.url },
  { name: "OpenAI", logo: openAi.url },
  { name: "Render", logo: render.url },
  { name: "Medfin", logo: medfin.url },
  { name: "GrowthX", logo: growthX.url },
  { name: "NeuralArc", logo: neuralArc.url },
  { name: "Autodesk", logo: autodesk.url },
  { name: "Sprinklr", logo: sprinklr.url },
  { name: "CloudEagle.ai", logo: cloudEagle.url },
  { name: "Paperflite", logo: paperflite.url },
  { name: "Technology Innovation Institute", logo: tii.url },
  { name: "Skoob", logo: skoob.url },
  { name: "Dodo Payments", logo: dodoPayments.url },
  { name: ".XYZ", logo: xyz.url },
  { name: "Miro", logo: miro.url },
  { name: "JioStar", logo: jioStar.url },
  { name: "Deloitte", logo: deloitte.url },
  { name: "Visa", logo: visa.url },
  { name: "Morgan Stanley", logo: morganStanley.url },
  { name: "Oracle", logo: oracle.url },
  { name: "Salesforce", logo: salesforce.url },
  { name: "American Express", logo: americanExpress.url },
  { name: "Accenture", logo: accenture.url },
  { name: "MIT", logo: mit.url },
  { name: "ETH Zurich", logo: ethZurich.url },
  { name: "IIT Bombay", logo: iitBombay.url },
  { name: "IIT Kanpur", logo: iitKanpur.url },
  { name: "IIT Roorkee", logo: iitRoorkee.url },
  { name: "Imperial College London", logo: imperialCollege.url },
  { name: "Harvard University", logo: harvard.url },
  { name: "University of Cambridge", logo: cambridge.url },
  { name: "University of Oxford", logo: oxford.url },
  { name: "University of Illinois Chicago", logo: illinoisChicago.url },
  { name: "Stanford University", logo: stanford.url },
];

export function PartnerShowcase() {
  return (
    <section className="partner-showcase paper-texture" aria-labelledby="partners-title">
      <div className="partner-showcase-shell">
        <header className="partner-showcase-heading">
          <p className="partner-showcase-kicker">Made with people, not around them.</p>
          <h2 id="partners-title">People who joined us in the past.</h2>
          <p>People have joined us from teams and institutions around the world.</p>
        </header>

        <ul className="partner-logo-wall" aria-label="Organizations and institutions represented in past gatherings">
          {organizations.map((organization) => (
            <li className="partner-logo-tile" key={organization.name}>
              <span className="partner-logo-mark">
                <img src={organization.logo} alt="" loading="lazy" />
              </span>
              <span>{organization.name}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}