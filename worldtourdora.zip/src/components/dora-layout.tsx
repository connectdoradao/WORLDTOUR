import { Link } from "@tanstack/react-router";
import { Menu, X, Instagram, Linkedin, Twitter, Globe, Mail, CalendarHeart, Rocket } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { JoinJourney } from "@/components/join-journey";
import tourLogo from "@/assets/world-tour-ft-dora-logo.svg.asset.json";

const nav = [
  { label: "Cities", to: "/cities" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/95 backdrop-blur">
    <div className="mx-auto grid h-16 max-w-[1480px] grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 lg:grid-cols-[1fr_auto_1fr] lg:px-8">
      <Link to="/" className="site-brand-logo" aria-label="World Tour featuring Dora — home" onClick={() => setOpen(false)}><img src={tourLogo.url} alt="World Tour featuring Dora" /></Link>
      <nav className="hidden items-center gap-4 lg:flex xl:gap-6" aria-label="Primary navigation">{nav.map(item => <Link key={item.to} to={item.to} className="font-display text-xs text-muted-foreground transition-colors hover:text-coral xl:text-sm" activeProps={{ className: "text-foreground underline decoration-coral decoration-2 underline-offset-8" }}>{item.label}</Link>)}</nav>
      <div className="flex justify-end gap-2"><JoinJourney defaultRole="city"><Button variant="outline" size="sm" className="hidden rounded-full sm:inline-flex">Bring Dora to my city</Button></JoinJourney><Button variant="ghost" size="icon" className="min-h-11 min-w-11 lg:hidden" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(v => !v)}>{open ? <X /> : <Menu />}</Button></div>
    </div>
    {open && <nav className="border-t border-border bg-paper px-5 py-5 lg:hidden" aria-label="Mobile navigation"><div className="flex flex-col">{nav.map(item => <Link key={item.to} to={item.to} className="border-b border-border py-4 font-poster text-2xl" onClick={() => setOpen(false)}>{item.label}</Link>)}<JoinJourney defaultRole="city"><Button className="mt-5 h-12 rounded-full">Bring Dora to my city</Button></JoinJourney></div></nav>}
  </header>;
}

const flags = ["🇯🇵","🇮🇳","🇺🇸","🇸🇬","🇨🇳","🇳🇵","🇮🇩","🇵🇭","🇻🇳","🇪🇺","🇷🇺","🇱🇰"] as const;
const socials = [
  { label: "Website", href: "https://www.connectdoradao.xyz", icon: Globe },
  { label: "LinkedIn", href: "https://www.linkedin.com/company/doradao/", icon: Linkedin },
  { label: "Instagram", href: "https://www.instagram.com/connectdoradao/", icon: Instagram },
  { label: "X (Twitter)", href: "https://x.com/connectdoradao", icon: Twitter },
  { label: "Substack", href: "https://doradao.substack.com", icon: Mail },
  { label: "Luma", href: "https://luma.com/connectdoradao", icon: CalendarHeart },
  { label: "Product Hunt", href: "https://www.producthunt.com/@dora_dao", icon: Rocket },
] as const;

export function SiteFooter() {
  return <footer className="site-footer">
    <div className="footer-torn" aria-hidden="true" />
    <div className="mx-auto max-w-7xl px-5 pt-12 pb-8 lg:px-8">
      <div className="grid gap-12 lg:grid-cols-12">
        <div className="lg:col-span-5">
          <Link to="/" className="footer-brand-logo" aria-label="World Tour featuring Dora — home"><img src={tourLogo.url} alt="World Tour featuring Dora" /></Link>
          <p className="mt-5 max-w-md text-sm font-semibold leading-6 text-footer-foreground/85">DoraDAO is a non-profit community on a mission to make emerging tech accessible, inclusive, and human — not just for hardcore tech experts, but for everyone.</p>
          <p className="mt-4 max-w-md text-sm font-semibold leading-6 text-footer-foreground/85">60k+ members from over 15+ countries and beyond are coming together.</p>
          <p className="footer-flags mt-3" aria-hidden="true">{flags.map(f => <span key={f}>{f}</span>)}</p>
        </div>
        <div className="lg:col-span-4">
          <FooterGroup title="Explore" links={[["Cities","/cities"],["FAQ","/faq"]]} />
        </div>
        <div className="lg:col-span-3">
          <p className="mb-4 text-xs uppercase tracking-widest text-footer-foreground/60">Follow along</p>
          <div className="flex flex-wrap gap-2.5">
            {socials.map(({ label, href, icon: Icon }) => (
              <a key={label} href={href} target="_blank" rel="noreferrer" className={`footer-social ${label === "Website" ? "footer-social-hero" : ""}`}>
                <Icon aria-hidden="true" /> {label}
              </a>
            ))}
          </div>
        </div>
      </div>
      <svg className="footer-doodle mt-12" viewBox="0 0 1200 64" aria-hidden="true" fill="none">
        <path d="M8 42 C 190 8, 380 58, 590 26 S 990 6, 1120 32" stroke="currentColor" strokeWidth="2" strokeDasharray="7 9" strokeLinecap="round" />
        <path d="M1112 36 l30 -10 -12 18 -5 -8 z" fill="currentColor" />
      </svg>
      <div className="mt-8 flex flex-wrap items-end justify-between gap-6 border-t border-footer-foreground/20 pt-6">
        <p className="text-sm font-semibold text-footer-foreground/85">Made by people.<br />For people.</p>
        <a href="https://www.connectdoradao.xyz" target="_blank" rel="noreferrer" className="footer-link text-sm">www.connectdoradao.xyz</a>
        <span className="text-xs text-footer-foreground/60">© DoraDAO</span>
      </div>
    </div>
  </footer>;
}

function FooterGroup({ title, links }: { title: string; links: readonly (readonly [string, string])[] }) { return <div><p className="mb-4 text-xs uppercase tracking-widest text-footer-foreground/60">{title}</p><ul className="space-y-3">{links.map(([label,to]) => <li key={label}><Link to={to} className="text-sm hover:underline">{label}</Link></li>)}</ul></div>; }

export function PageFrame({ children }: { children: ReactNode }) { return <><SiteHeader/><main id="main-content">{children}</main><SiteFooter/><div className="mobile-sticky-cta"><JoinJourney defaultRole="city"><Button className="h-12 w-full rounded-full shadow-lg">Bring Dora here</Button></JoinJourney></div></>; }

export function SectionHeading({ eyebrow, title, copy }: { eyebrow?: string; title: string; copy?: string }) { return <div className="max-w-2xl">{eyebrow && <p className="campaign-kicker mb-3">{eyebrow}</p>}<h2 className="text-balance font-poster text-4xl leading-[1.05] sm:text-5xl">{title}</h2>{copy && <p className="mt-4 max-w-xl text-base leading-7 text-muted-foreground">{copy}</p>}</div>; }