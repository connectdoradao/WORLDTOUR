import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { JoinJourney } from "@/components/join-journey";
import { HowItWorksCards } from "@/components/how-it-works";

/* ---------- shared bits ---------- */
export function Chapter({ number, label, tone = "coral" }: { number: string; label: string; tone?: "coral" | "sun" }) {
  void number; void label; void tone; return null;
}

function Flow({ steps, light = false }: { steps: string[]; light?: boolean }) {
  return <ol className={`story-flow ${light ? "story-flow-light" : ""}`} aria-label="How it connects">
    {steps.map((s, i) => <li key={s}><span>{s}</span>{i < steps.length - 1 && <i aria-hidden="true">→</i>}</li>)}
  </ol>;
}

/* ---------- 03 So... what actually happens? ---------- */
export function WhatHappens() {
  return <section className="story-section process-section paper-texture" aria-labelledby="happens-title">
    <div className="home-shell">
      <Chapter number="03" label="How it works" />
      <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
        <h2 id="happens-title" className="home-heading">So… what actually happens?</h2>
        <p className="max-w-lg text-lg leading-7">World Tour turns a global idea into something local, human and real.</p>
      </div>
      <p className="story-concept mt-8">“World Tour is a DoraDAO initiative that takes our belief in human connection off the screen and into the real world.”</p>
      <HowItWorksCards />
      <p className="story-spark">The tour isn't the destination. <strong>It's the spark.</strong></p>
    </div>
  </section>;
}

/* ---------- 04 Who is Dora? ---------- */
const trio = [
  { name: "Dora", role: "The character.", copy: "The curious little traveller who represents the spirit of the movement.", tone: "trio-sun" },
  { name: "DoraDAO", role: "The community.", copy: "People building more accessible, inclusive and human ways to learn, create and belong.", tone: "trio-green" },
  { name: "World Tour", role: "The journey.", copy: "A real-world initiative taking that belief from screens into cities, rooms, trails and communities.", tone: "trio-coral" },
];

export function WhoIsDora() {
  return <section className="story-section story-sky" aria-labelledby="dora-title">
    <div className="home-shell">
      <Chapter number="04" label="Who's who" tone="sun" />
      <h2 id="dora-title" className="home-heading mt-7">Okay, but who is Dora?</h2>
      <div className="trio-grid mt-10">
        {trio.map((t, i) => <article key={t.name} className={`trio-card ${t.tone}`} style={{ rotate: `${[-2, 1, -1][i]}deg` }}>
          <p className="trio-stamp">{t.role}</p>
          <h3>{t.name}</h3>
          <p>{t.copy}</p>
        </article>)}
      </div>
      <Flow steps={["Dora", "World Tour", "People", "Communities"]} />
      <p className="story-concept mt-8">“Dora doesn't come to a city just to host an event. She comes to help people create something that stays after the event is over.”</p>
    </div>
  </section>;
}

/* ---------- 06 The loop ---------- */
const loop = ["Experience", "Connection", "Community", "Local culture", "Impact", "Another experience"];
export function TourLoop() {
  return <section className="story-section story-green" aria-labelledby="loop-title">
    <div className="home-shell grid gap-10 lg:grid-cols-[.9fr_1.1fr] lg:items-center">
      <div>
        <Chapter number="06" label="The tour is a loop" tone="sun" />
        <h2 id="loop-title" className="home-heading mt-7">One experience can become something bigger.</h2>
        <p className="mt-6 max-w-md text-lg leading-7 opacity-90">We're not trying to create events people attend once. We're creating conditions where people keep showing up for each other.</p>
      </div>
      <ol className="loop-ring" aria-label="The loop">
        {loop.map((l, i) => <li key={l} style={{ ["--i" as string]: i }}><span>{String(i + 1).padStart(2, "0")}</span>{l}</li>)}
        <p className="loop-center" aria-hidden="true">↻<br />again</p>
      </ol>
    </div>
  </section>;
}

/* ---------- 08 City lifecycle ---------- */
const lifecycle = ["Someone asks for Dora.", "A local person or group starts building.", "We shape the first experience together.", "People show up.", "More experiences happen.", "The local community decides what comes next."];
export function CityLifecycle() {
  return <section className="story-section story-cream paper-texture" aria-labelledby="lifecycle-title">
    <div className="home-shell">
      <Chapter number="05" label="How a city becomes a stop" />
      <div className="grid gap-5 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
        <h2 id="lifecycle-title" className="home-heading">Request → Build → Gather → Continue.</h2>
        <p className="story-principle">Every city should feel like itself.</p>
      </div>
      <ol className="ticket-row mt-10">
        {lifecycle.map((s, i) => <li key={s} className="ticket"><span>Stop {i + 1}</span><p>{s}</p></li>)}
      </ol>
      <p className="mt-6 max-w-2xl text-sm font-semibold leading-6 text-muted-foreground">DoraDAO doesn't run every event from the centre. Local people shape their stop — we help with the spark, the tools and the network.</p>
    </div>
  </section>;
}

/* ---------- 10 Events: tour taking shape ---------- */
const exampleStops = [
  { title: "Long Table", pillar: "Gather", line: "Strangers share one dinner." },
  { title: "Teach Me Your Job", pillar: "Grow", line: "Someone explains what they actually do all day." },
  { title: "Adopt a Patch", pillar: "Give", line: "A local green space, cared for together." },
  { title: "Sunrise Mission", pillar: "Move", line: "Meet early, watch the city wake up." },
  { title: "Paint the Wall", pillar: "Make", line: "A mural nobody could make alone." },
];
export function TourTakingShape() {
  return <section className="home-stage paper-texture" aria-labelledby="events-title">
    <div className="home-shell">
      <Chapter number="06" label="What's happening" />
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div><p className="campaign-kicker">The tour is taking shape.</p><h2 id="events-title" className="home-heading">What's happening around the tour.</h2></div>
        <p className="max-w-sm text-sm font-semibold leading-6">These are examples of what a Dora stop can look like. Confirmed experiences will appear here as cities come alive.</p>
      </div>
      <ul className="events-list mt-8">
        {exampleStops.map(e => <li key={e.title}>
          <p className="event-date-block"><strong>TBC</strong><span>Example</span></p>
          <div className="event-row-main"><h3>{e.title}</h3><p>{e.line}</p></div>
          <span className={`event-row-pill event-category category-${e.pillar.toLowerCase()}`}>{e.pillar}</span>
          <JoinJourney defaultRole="experience"><Button variant="outline" className="event-row-cta rounded-full">Get first access</Button></JoinJourney>
        </li>)}
      </ul>
      <div className="mt-9 flex flex-wrap justify-center gap-3">
        <JoinJourney defaultRole="city"><Button className="rounded-full px-7">Bring Dora to my city</Button></JoinJourney>
        <Button asChild variant="outline" className="rounded-full px-7"><Link to="/cities">Explore the tour <ArrowRight /></Link></Button>
      </div>
    </div>
  </section>;
}

/* ---------- 11 What stays ---------- */
const stayPrompts = ["A tree that stays.", "A student who found a mentor.", "A reading club that grew.", "A local culture that travelled.", "A community that kept meeting.", "A friendship that started with a stranger."];
export function WhatStays() {
  return <section className="story-section story-sky" aria-labelledby="stays-title">
    <div className="home-shell">
      <Chapter number="11" label="Impact" tone="sun" />
      <div className="mt-7 grid gap-5 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
        <h2 id="stays-title" className="home-heading">What stays after Dora leaves?</h2>
        <p className="max-w-md text-lg leading-7">No vanity metrics. Just what stayed — city, what happened, who started it, what continued.</p>
      </div>
      <div className="swipe-row mt-10">
        {stayPrompts.map((p, i) => <article key={p} className="stay-card" style={{ rotate: `${i % 2 ? 1.5 : -1.5}deg` }}>
          <p className="trio-stamp">Awaiting a real story</p>
          <h3>{p}</h3>
          <dl><div><dt>City</dt><dd>—</dd></div><div><dt>Started by</dt><dd>—</dd></div><div><dt>What continued</dt><dd>—</dd></div></dl>
        </article>)}
      </div>
      <p className="story-empty mt-8">Stories will appear here as the tour creates them.</p>
      
    </div>
  </section>;
}

/* ---------- 12 Postcards ---------- */
const postcards = [
  { line: "I came alone.", meta: "Any city · A Long Table" },
  { line: "A city in 24 hours.", meta: "Any city · A Sunrise Mission" },
  { line: "The person who hosted their first dinner.", meta: "Any city · First-timer dinner" },
];
export function Postcards() {
  return <section className="story-section story-cream paper-texture" aria-labelledby="postcards-title">
    <div className="home-shell">
      <Chapter number="12" label="Postcards from the road" />
      <div className="mt-7 grid gap-5 lg:grid-cols-[1.1fr_.9fr] lg:items-end">
        <h2 id="postcards-title" className="home-heading">People. Cities. Small moments.</h2>
        <p className="max-w-md text-sm font-semibold leading-6">These are example postcards — the kind of story we'll share once real stops happen.</p>
      </div>
      <div className="swipe-row mt-10">
        {postcards.map((p, i) => <article key={p.line} className="postcard" style={{ rotate: `${[-2, 1.5, -1][i]}deg` }}>
          <div className="postcard-stamp" aria-hidden="true">DORA</div>
          <p className="trio-stamp">Example story</p>
          <h3>“{p.line}”</h3>
          <p className="postcard-meta">{p.meta}</p>
        </article>)}
      </div>
      <Button asChild variant="outline" className="mt-9 rounded-full"><Link to="/stories">Read the postcards <ArrowRight /></Link></Button>
    </div>
  </section>;
}

/* ---------- 13 Being there ---------- */
export function BeingThere() {
  return <section className="story-section story-ink" aria-labelledby="ai-title">
    <div className="home-shell">
      <Chapter number="13" label="Why now" tone="sun" />
      <h2 id="ai-title" className="home-heading mt-7">AI can generate almost everything.</h2>
      <p className="ai-list mt-6">Images. Music. Code. Answers. Ideas. Conversations.</p>
      <p className="mt-8 text-xl">So what becomes more valuable?</p>
      <p className="ai-big">Being there.</p>
      <ul className="ai-moments mt-8">{["A table.", "A trail.", "Someone teaching.", "Someone listening.", "A hand on a shoulder.", "A room full of strangers becoming familiar."].map(m => <li key={m}>{m}</li>)}</ul>
      <p className="mt-10 max-w-2xl text-lg leading-7 opacity-90">The easier it becomes to create things digitally, the more valuable real presence becomes. DoraDAO loves technology — we just want it to help people show up, not replace showing up. <strong className="text-sun">That's what World Tour is protecting.</strong></p>
      <div className="vision mt-14">
        <p className="campaign-kicker text-sun">The longer vision</p>
        <p className="vision-title">We're not building an events calendar. We're building the infrastructure for people to belong.</p>
        <Flow light steps={["One experience", "One connection", "One community", "One city", "A network of cities", "A culture of belonging"]} />
      </div>
    </div>
  </section>;
}

/* ---------- 15 + 16 Final CTA / back cover ---------- */
export function FinalCta() {
  return <section className="host-cta-section" aria-labelledby="final-title"><div className="home-shell"><div className="host-cta-band">
    <h2 id="final-title">Do you want to help create a world where people still show up for each other?</h2>
    <p className="host-cta-copy">Come to something. Host something. Bring Dora to your city. Every way in counts.</p>
    <div className="flex flex-wrap justify-center gap-3">
      <JoinJourney><Button className="rounded-full bg-sun px-8 text-ink hover:bg-sun/90">Find your way in <ArrowRight /></Button></JoinJourney>
      <JoinJourney defaultRole="city"><Button variant="outline" className="host-cta-button rounded-full px-8">Bring Dora to my city</Button></JoinJourney>
    </div>
  </div></div></section>;
}
