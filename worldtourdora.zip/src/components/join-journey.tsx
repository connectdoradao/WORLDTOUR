import { useState, type ReactNode } from "react";
import { Check, Heart, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { saveFormSubmission } from "@/lib/form-submissions.functions";

type Role = "experience" | "host" | "collaborate" | "support" | "volunteer";
type LegacyRole = Role | "city";
const roles: { id: Role; label: string }[] = [
  { id: "experience", label: "Attend" },
  { id: "host", label: "Host / bring Dora" },
  { id: "collaborate", label: "Community / resources" },
  { id: "support", label: "Support" },
  { id: "volunteer", label: "Volunteer" },
];
const roleCopy: Record<Role, string> = {
  experience: "We'll tell you first when something opens near you.",
  host: "We'll reach out to shape the idea for your city together.",
  collaborate: "Now let's see what we can make happen together.",
  support: "Thank you for helping experiences happen.",
  volunteer: "Thank you for offering your time and skills. We'll be in touch.",
};
const volunteerRoles = ["Design Team", "Developer Team", "Community Manager", "Event Manager", "University / Campus Team", "Video Editor", "Media Team", "Community Team", "Influencer Team (500–10K+ followers)", "Sponsorship Team"];
const applicantTypes = ["Community", "Individual", "Company", "Institution"];
const contributionOptions = ["I already have a community", "I have a space", "I have a skill", "I have a resource"];
const supportOptions = ["Offline Space", "Credits", "Funding", "Physical Merch", "Media Support", "Others"];

export function JoinJourney({ children, defaultRole = "experience" }: { children: ReactNode; defaultRole?: LegacyRole }) {
  const [role, setRole] = useState<Role>(defaultRole === "city" ? "host" : defaultRole);
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!event.currentTarget.reportValidity()) return;
    const formData = new FormData(event.currentTarget);
    if ((role === "collaborate" && formData.getAll("resources").length === 0) || (role === "support" && formData.getAll("supportOffer").length === 0)) {
      setErrorMessage("Choose at least one option."); setStatus("error"); return;
    }
    const values: Record<string, string | string[]> = {};
    for (const [key, value] of formData.entries()) { const clean = String(value).trim(); const current = values[key]; values[key] = current === undefined ? clean : Array.isArray(current) ? [...current, clean] : [current, clean]; }
    setErrorMessage(""); setStatus("loading");
    try { await saveFormSubmission({ data: { formType: "join-journey", role, fields: values } }); setStatus("done"); }
    catch { setErrorMessage("We couldn't save your response. Please try again."); setStatus("error"); }
  }
  return <Dialog onOpenChange={open => { if (!open) setTimeout(() => { setStatus("idle"); setErrorMessage(""); }, 200); }}><DialogTrigger asChild>{children}</DialogTrigger><DialogContent className="paper-texture max-h-[92dvh] max-w-3xl overflow-y-auto border-2 border-ink/20 bg-paper p-0 sm:rounded-sm">
    {status === "done" ? <div className="grid min-h-96 place-items-center p-10 text-center"><div><span className="mx-auto grid size-16 place-items-center rounded-full bg-sun"><Heart className="size-7"/></span><DialogTitle className="mt-6 font-poster text-4xl">You're in.</DialogTitle><DialogDescription className="mx-auto mt-3 max-w-md text-base text-foreground">{roleCopy[role]}</DialogDescription></div></div> : <>
      <DialogHeader className="border-b-2 ink-rule px-6 py-5 text-left sm:px-8"><p className="font-hand text-xl text-coral">People × Community × Impact</p><DialogTitle className="font-poster text-3xl sm:text-4xl">Find your way in.</DialogTitle><DialogDescription>Choose how you want to take part.</DialogDescription></DialogHeader>
      <div className="grid gap-6 p-6 sm:p-8"><div className="flex gap-2 overflow-x-auto pb-2" role="radiogroup" aria-label="Choose how to join">{roles.map(item => <Button key={item.id} type="button" variant={role === item.id ? "default" : "outline"} className="min-h-11 shrink-0 rounded-full" onClick={() => { setRole(item.id); setStatus("idle"); setErrorMessage(""); }} role="radio" aria-checked={role === item.id}>{role === item.id && <Check/>}{item.label}</Button>)}</div>
        <form onSubmit={submit} className="grid gap-5 animate-in fade-in duration-300"><RoleFields role={role}/><Button type="submit" className="min-h-12 rounded-full" disabled={status === "loading"}>{status === "loading" && <Loader2 className="animate-spin"/>}{role === "host" ? "Host or bring Dora" : role === "collaborate" ? "Build with us" : role === "support" ? "Support the movement" : role === "volunteer" ? "Volunteer with us" : "I'm in"}</Button><p className={`text-xs ${status === "error" ? "text-destructive" : "text-muted-foreground"}`} aria-live="polite">{status === "error" ? errorMessage : "Your response is saved securely so the team can follow up."}</p></form>
      </div>
    </>}
  </DialogContent></Dialog>;
}

function RoleFields({ role }: { role: Role }) {
  if (role === "experience") return <div className="grid gap-5 sm:grid-cols-2"><Field name="email" label="Email" type="email"/><Field name="contact" label="Contact number" type="tel"/><Field name="social" label="Social link"/><Field name="city" label="City"/><Field name="country" label="Country"/></div>;
  if (role === "host") return <div className="grid gap-5 sm:grid-cols-2"><Field name="fullName" label="Full Name"/><Field name="country" label="Country"/><Field name="region" label="State / Province / Region"/><Field name="city" label="City"/><SelectField name="applicantType" label="Community / Individual / Company / Institution" options={applicantTypes}/><Field name="organization" label="University / Organization"/><Field name="currentRole" label="Current role"/><Field name="communitySize" label="Community size" type="number"/><TextField name="previousEvents" label="Previous events organised"/><Field name="expectedAttendance" label="Expected attendance" type="number"/><Field name="social" label="Social links"/></div>;
  if (role === "collaborate") return <><div className="grid gap-5 sm:grid-cols-2"><Field name="fullName" label="Full Name"/><Field name="email" label="Email" type="email"/><Field name="contact" label="Contact number" type="tel"/><Field name="social" label="Social link"/><Field name="city" label="City"/><Field name="country" label="Country"/></div><CheckboxGroup legend="What can you bring?" name="resources" options={contributionOptions}/></>;
  if (role === "support") return <><div className="grid gap-5 sm:grid-cols-2"><Field name="companyName" label="Company Name"/><Field name="pocName" label="POC Name"/><Field name="pocRole" label="POC Role"/><Field name="pocEmail" label="POC Email" type="email"/><Field name="pocContact" label="POC Contact Number" type="tel"/></div><CheckboxGroup legend="What are you willing to offer?" name="supportOffer" options={supportOptions}/></>;
  return <div className="grid gap-5 sm:grid-cols-2"><Field name="fullName" label="Full Name"/><Field name="email" label="Email" type="email"/><Field name="contact" label="Contact info" type="tel"/><Field name="social" label="Socials (LinkedIn / Instagram)"/><Field name="cityState" label="City and State"/><Field name="country" label="Country"/><SelectField name="volunteerRole" label="Role" options={volunteerRoles}/><TextField name="pastExperience" label="Past Experience"/></div>;
}
function Field({ name, label, type = "text" }: { name: string; label: string; type?: string }) { const id = `join-${name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`; return <div><Label htmlFor={id} className="font-hand text-xl">{label}</Label><Input id={id} name={name} type={type} required min={type === "number" ? 0 : undefined} maxLength={type === "email" || type === "url" ? 255 : 120} className="mt-2 h-11 rounded-none border-0 border-b-2 border-input bg-transparent px-1"/></div>; }
function SelectField({ name, label, options }: { name: string; label: string; options: string[] }) { const id = `join-${name}`; return <div><Label htmlFor={id} className="font-hand text-xl">{label}</Label><select id={id} name={name} required className="mt-2 h-11 w-full border-0 border-b-2 border-input bg-transparent px-1 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"><option value="">Select one</option>{options.map(option => <option key={option}>{option}</option>)}</select></div>; }
function TextField({ name, label }: { name: string; label: string }) { const id = `join-${name}`; return <div className="sm:col-span-2"><Label htmlFor={id} className="font-hand text-xl">{label}</Label><Textarea id={id} name={name} required maxLength={1000} className="mt-2 min-h-24 rounded-none border-0 border-b-2 border-input bg-transparent px-1"/></div>; }
function CheckboxGroup({ legend, name, options }: { legend: string; name: string; options: string[] }) { return <fieldset><legend className="mb-3 font-hand text-xl">{legend}</legend><div className="grid gap-3 sm:grid-cols-2">{options.map(option => <label key={option} className="flex min-h-11 items-center gap-3 border border-border bg-paper/60 px-3 text-sm"><input type="checkbox" name={name} value={option}/>{option}</label>)}</div></fieldset>; }
