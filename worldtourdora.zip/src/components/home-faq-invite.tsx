import { Link } from "@tanstack/react-router";
import { ArrowRight, MessageCircleQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Chapter } from "@/components/home-story";

export function HomeFaqInvite() {
  return <section className="home-faq-invite paper-texture" aria-labelledby="home-faq-title">
    <div className="home-shell">
      <Chapter number="07" label="FAQ" />
      <div className="home-faq-invite-inner">
        <MessageCircleQuestion aria-hidden="true" />
        <div><p className="campaign-kicker">Questions people actually ask</p><h2 id="home-faq-title">Before you show up, here's everything.</h2></div>
        <Button asChild variant="outline" className="rounded-full"><Link to="/faq">Open the FAQ <ArrowRight /></Link></Button>
      </div>
    </div>
  </section>;
}
