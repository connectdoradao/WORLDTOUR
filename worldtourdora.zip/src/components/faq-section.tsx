"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { JoinJourney } from "@/components/join-journey";
import { faqCategories, faqCategorySlugs, faqData, type FaqCategory } from "@/lib/faq-data";

const slugToCategory = Object.fromEntries(Object.entries(faqCategorySlugs).map(([category, slug]) => [slug, category])) as Record<string, FaqCategory>;

function categoryFromHash(): FaqCategory {
  if (typeof window === "undefined") return "General";
  return slugToCategory[window.location.hash.slice(1)] ?? "General";
}

export function FaqSection() {
  const reduceMotion = useReducedMotion();
  const [activeCategory, setActiveCategory] = useState<FaqCategory>("General");
  const [openQuestion, setOpenQuestion] = useState<string | null>(null);

  useEffect(() => {
    const syncHash = () => {
      setActiveCategory(categoryFromHash());
      setOpenQuestion(null);
    };
    syncHash();
    window.addEventListener("hashchange", syncHash);
    return () => window.removeEventListener("hashchange", syncHash);
  }, []);

  const visibleQuestions = useMemo(() => faqData.filter((item) => item.category === activeCategory), [activeCategory]);

  function selectCategory(category: FaqCategory) {
    setActiveCategory(category);
    setOpenQuestion(null);
    window.history.replaceState(null, "", `#${faqCategorySlugs[category]}`);
  }

  return <>
    <div className="faq-tabs" role="tablist" aria-label="FAQ categories">
      {faqCategories.map((category) => <Button
        key={category}
        id={`faq-tab-${faqCategorySlugs[category]}`}
        type="button"
        role="tab"
        variant={activeCategory === category ? "default" : "outline"}
        aria-selected={activeCategory === category}
        aria-controls={`faq-panel-${faqCategorySlugs[category]}`}
        tabIndex={activeCategory === category ? 0 : -1}
        className="rounded-full"
        onClick={() => selectCategory(category)}
      >{category}</Button>)}
    </div>

    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={activeCategory}
        id={`faq-panel-${faqCategorySlugs[activeCategory]}`}
        role="tabpanel"
        aria-labelledby={`faq-tab-${faqCategorySlugs[activeCategory]}`}
        className="faq-list"
        initial={reduceMotion ? false : { opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={reduceMotion ? { opacity: 1 } : { opacity: 0, y: -6 }}
        transition={{ duration: reduceMotion ? 0 : 0.18, ease: "easeOut" }}
      >
        {visibleQuestions.map((item, index) => {
          const isOpen = openQuestion === item.question;
          const panelId = `faq-answer-${faqCategorySlugs[activeCategory]}-${index}`;
          return <article key={item.question} className={`faq-item ${isOpen ? "is-open" : ""}`}>
            <button
              type="button"
              className="faq-question"
              aria-expanded={isOpen}
              aria-controls={panelId}
              onClick={() => setOpenQuestion(isOpen ? null : item.question)}
            >
              <span>{item.question}</span>
              <span className="faq-plus" aria-hidden="true"><Plus /></span>
            </button>
            <motion.div
              id={panelId}
              className="faq-answer"
              initial={false}
              animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
              transition={{ height: { duration: reduceMotion ? 0 : 0.2 }, opacity: { duration: reduceMotion ? 0 : 0.16 } }}
            >
              <p>{item.answer}</p>
            </motion.div>
          </article>;
        })}
      </motion.div>
    </AnimatePresence>

    <div className="faq-closing">
      <div><p className="font-hand text-2xl text-coral">One more thing?</p><h2>Still have a question we didn't cover?</h2></div>
      <JoinJourney defaultRole="collaborate"><Button className="rounded-full">Ask us directly <ArrowRight /></Button></JoinJourney>
    </div>
  </>;
}
