import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowUpRight,
  BookOpen,
  BriefcaseBusiness,
  ChefHat,
  CircleHelp,
  Clapperboard,
  Gamepad2,
  GraduationCap,
  HandHeart,
  Hammer,
  Home,
  Lightbulb,
  Map,
  Music,
  Paintbrush,
  Repeat2,
  Sprout,
  Sunrise,
  Trees,
  Users,
  Utensils,
  Wrench,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

type Activity = { title: string; description: string; icon: LucideIcon };
type TourPhone = {
  id: string;
  number: string;
  name: string;
  action: string;
  tagline: string;
  feeling: string;
  angle: number;
  examples: [number, number];
  activities: Activity[];
};

const phones: TourPhone[] = [
  {
    id: "gather",
    number: "01",
    name: "Gather",
    action: "Belong",
    tagline: "Find your people.",
    feeling: "Oh. These are my people.",
    angle: -4,
    examples: [0, 3],
    activities: [
      { title: "Long Table", description: "Strangers share one ridiculous dinner table", icon: Utensils },
      { title: "Open House", description: "Someone opens their home for an evening", icon: Home },
      { title: "Culture Swap", description: "Bring your food, music, stories", icon: Music },
      { title: "Game Night", description: "Board games, cards, competitive chaos", icon: Gamepad2 },
      { title: "First-Timer Nights", description: "Designed for people who don't know anyone", icon: Users },
    ],
  },
  {
    id: "grow",
    number: "02",
    name: "Grow",
    action: "Learn",
    tagline: "Leave knowing something new.",
    feeling: "Wait… I can actually learn this.",
    angle: 2,
    examples: [0, 3],
    activities: [
      { title: "Teach Me Your Job", description: "What do you actually do all day?", icon: BriefcaseBusiness },
      { title: "Reverse Mentorship", description: "Students teach professionals", icon: GraduationCap },
      { title: "Office Hours", description: "Ask someone who's already done it", icon: CircleHelp },
      { title: "Failure School", description: "People openly share what went wrong", icon: BookOpen },
      { title: "Skill Barter", description: "Trade one skill for another", icon: Repeat2 },
    ],
  },
  {
    id: "give",
    number: "03",
    name: "Give",
    action: "Contribute",
    tagline: "Do something that doesn't end with you.",
    feeling: "We actually left something better behind.",
    angle: -2,
    examples: [0, 4],
    activities: [
      { title: "Adopt a Patch", description: "Take responsibility for a local green space", icon: Trees },
      { title: "Digital Saturdays", description: "Help someone get online", icon: Lightbulb },
      { title: "Repair, Don't Replace", description: "Fix things together", icon: Wrench },
      { title: "Pro-Bono Hours", description: "Donate real professional expertise", icon: HandHeart },
      { title: "Community Kitchen", description: "Cook and distribute together", icon: ChefHat },
    ],
  },
  {
    id: "move",
    number: "04",
    name: "Move",
    action: "Experience",
    tagline: "Go somewhere you've never been.",
    feeling: "I would've never discovered this on my own.",
    angle: 4,
    examples: [2, 1],
    activities: [
      { title: "Mystery City Day", description: "You don't know where you're going until you arrive", icon: Map },
      { title: "Walk With a Stranger", description: "Two people, one route, one conversation", icon: Users },
      { title: "Sunrise Missions", description: "Meet at 5:30am, watch the city wake up", icon: Sunrise },
      { title: "Hidden City Tours", description: "Locals show what tourists never see", icon: ArrowUpRight },
      { title: "Lost Together", description: "Deliberately explore with no itinerary", icon: Map },
    ],
  },
  {
    id: "make",
    number: "05",
    name: "Make",
    action: "Create",
    tagline: "Turn ‘someone should’ into ‘we did.’",
    feeling: "Wait… WE made that.",
    angle: -3,
    examples: [0, 1],
    activities: [
      { title: "48-Hour Film", description: "Strangers make a film in one weekend", icon: Clapperboard },
      { title: "Paint the Wall", description: "Collectively transform a forgotten space", icon: Paintbrush },
      { title: "Build Something Useful", description: "Benches, libraries, signs, shelters", icon: Hammer },
      { title: "One-Night Band", description: "People who've never played together, play together", icon: Music },
      { title: "Idea Playground", description: "Bring a crazy idea, find people to prototype it", icon: Sprout },
    ],
  },
];

const MotionButton = motion.create(Button);

export function TourPhones() {
  const [activeId, setActiveId] = useState<string>();
  const isMobile = useIsMobile();
  const active = phones.find((phone) => phone.id === activeId);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!active) return;
    const onKeyDown = (event: KeyboardEvent) => event.key === "Escape" && setActiveId(undefined);
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = "";
    };
  }, [active]);

  return <>
    <div className="tour-phone-grid" aria-label="Five ways to take part in the tour">
      {phones.map((phone, index) => <CollapsedPhone key={phone.id} phone={phone} index={index} onOpen={setActiveId}/>) }
    </div>
    <AnimatePresence>
      {active && <motion.div className="fixed inset-0 z-50 grid items-end justify-items-center sm:items-center" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
        <Button aria-label="Close expanded category" variant="ghost" className="absolute inset-0 h-auto w-auto rounded-none bg-ink/75 backdrop-blur-[3px] hover:bg-ink/75" onClick={() => setActiveId(undefined)}/>
        <ExpandedPhone phone={active} mobile={isMobile} closeRef={closeRef} onClose={() => setActiveId(undefined)}/>
      </motion.div>}
    </AnimatePresence>
  </>;
}

function CollapsedPhone({ phone, index, onOpen }: { phone: TourPhone; index: number; onOpen: (id: string) => void }) {
  const cards = phone.examples.map((activityIndex) => phone.activities[activityIndex]).filter((activity) => activity !== undefined);
  return <MotionButton
    layoutId={`tour-phone-${phone.id}`}
    type="button"
    variant="ghost"
    onClick={() => onOpen(phone.id)}
    initial={{opacity:0, y:34}}
    whileInView={{opacity:1, y:0}}
    viewport={{once:true, amount:.25}}
    transition={{delay:index * .08, type:"spring", stiffness:260, damping:24}}
    className={`tour-phone tour-phone-${phone.id} group h-auto whitespace-normal p-0 text-left hover:bg-transparent`}
    aria-label={`Open ${phone.name}: ${phone.tagline}`}
  >
    <span className="tour-phone-speaker" aria-hidden="true"/>
    <span className="tour-phone-content">
      <span className="tour-mini-stack">
        {cards.map((activity, cardIndex) => <MiniCard key={activity.title} activity={activity} front={cardIndex === 1}/>) }
      </span>
      <span className="tour-statement">
        <small>{phone.number} · {phone.action}</small>
        <strong>{phone.name}</strong>
        <span>{phone.tagline}</span>
      </span>
      <span className="tour-phone-prompt">Tap to open <ArrowUpRight aria-hidden="true"/></span>
    </span>
  </MotionButton>;
}

function MiniCard({ activity, front }: { activity: Activity; front: boolean }) {
  const Icon = activity.icon;
  return <span className={`tour-mini-card ${front ? "tour-mini-card-front" : ""}`}>
    <Icon aria-hidden="true"/>
    <span><strong>{activity.title}</strong><small>{activity.description}</small></span>
  </span>;
}

function ExpandedPhone({ phone, mobile, closeRef, onClose }: { phone: TourPhone; mobile: boolean; closeRef: React.RefObject<HTMLButtonElement | null>; onClose: () => void }) {
  const firstActivity = phone.activities[0];
  if (!firstActivity) return null;
  const CategoryIcon = firstActivity.icon;
  return <motion.article
    layoutId={`tour-phone-${phone.id}`}
    role="dialog"
    aria-modal="true"
    aria-labelledby={`tour-phone-title-${phone.id}`}
    transition={{type:"spring", stiffness:260, damping:24}}
    initial={mobile ? {y:"100%"} : false}
    animate={{y:0}}
    exit={mobile ? {y:"100%"} : {opacity:0}}
    className={`tour-phone-expanded tour-phone-${phone.id}`}
  >
    <div className="tour-phone-handle" aria-hidden="true"/>
    <Button ref={closeRef} type="button" variant="ghost" size="icon" aria-label={`Close ${phone.name}`} onClick={onClose} className="absolute right-4 top-4 z-10 min-h-11 min-w-11 rounded-full border border-current bg-paper/90"><X/></Button>
    <div className="tour-expanded-scroll">
      <header className="tour-expanded-header">
        <span className="tour-expanded-badge"><CategoryIcon aria-hidden="true"/></span>
        <p>{phone.number} · {phone.action}</p>
        <h3 id={`tour-phone-title-${phone.id}`}>{phone.name}</h3>
        <p className="tour-expanded-tagline">{phone.tagline}</p>
      </header>
      <div className="tour-activity-list">
        <p>Things we could do</p>
        {phone.activities.map((activity) => {
          const Icon = activity.icon;
          return <div key={activity.title} className="tour-activity">
            <span><Icon aria-hidden="true"/></span>
            <div><strong>{activity.title}</strong><p>{activity.description}</p></div>
          </div>;
        })}
      </div>
      <blockquote>“{phone.feeling}”</blockquote>
    </div>
  </motion.article>;
}