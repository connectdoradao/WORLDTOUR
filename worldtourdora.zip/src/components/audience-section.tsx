import { motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, HandHeart, Mic2, Newspaper, Sparkles, UserRound, UsersRound, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { JoinJourney } from "@/components/join-journey";

type JoinRole = "experience" | "host" | "collaborate" | "support" | "volunteer";
type Audience = { title: string; description: string; benefits: [string, string, string]; cta: string; icon: LucideIcon; role: JoinRole; tone: string };

const audiences: Audience[] = [
  { title: "I want to come.", description: "Find an experience and show up.", benefits: ["No membership needed", "Come alone — most people do", "First access when your city opens"], cta: "Find your way in", icon: UserRound, role: "experience", tone: "audience-card-attendee" },
  { title: "I want to host or bring Dora to my city.", description: "Create something people will remember.", benefits: ["Put your city on the list", "Shape a local experience", "Bring your community together"], cta: "Host in my city", icon: Mic2, role: "host", tone: "audience-card-host" },
  { title: "I have a community, space, skill or resource.", description: "Build something useful together.", benefits: ["Bring your people", "Offer a space or skill", "Co-create a local experience"], cta: "Build with us", icon: HandHeart, role: "collaborate", tone: "audience-card-community" },
  { title: "I want to support the movement.", description: "Help experiences happen.", benefits: ["Spread the word", "Help fund a stop", "Tell the story as it happens"], cta: "Support the movement", icon: Newspaper, role: "support", tone: "audience-card-media" },
  { title: "I want to volunteer.", description: "Join the team making each stop possible.", benefits: ["Contribute your skills", "Work with local teams", "Help create meaningful gatherings"], cta: "Volunteer with us", icon: UsersRound, role: "volunteer", tone: "audience-card-company" },
];

export function AudienceSection() {
  const reduceMotion = useReducedMotion();
  return <section className="audience-section" aria-labelledby="audience-title"><div className="audience-shell">
    <header className="audience-heading"><h2 id="audience-title">There's more than one way to be part of this.</h2><span aria-hidden="true"><Sparkles /></span></header>
    <motion.div className="audience-card-grid" initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.12 }} variants={{ hidden: {}, visible: { transition: { staggerChildren: reduceMotion ? 0 : 0.09 } } }}>
      {audiences.map((audience, index) => { const Icon = audience.icon; return <motion.article key={audience.title} className={`audience-card ${audience.tone}`} variants={{ hidden: { opacity: 0, y: reduceMotion ? 0 : 54, rotate: reduceMotion ? 0 : index % 2 === 0 ? -3 : 3 }, visible: { opacity: 1, y: 0, rotate: 0, transition: { type: "spring", stiffness: 150, damping: 20 } } }} {...(!reduceMotion ? { whileHover: { y: -12, rotate: index % 2 === 0 ? -1.2 : 1.2 } } : {})}>
        <motion.span className="audience-icon-tile" aria-hidden="true" {...(!reduceMotion ? { animate: { y: [0, -5, 0], rotate: [0, 3, 0] } } : {})} transition={{ duration: 4 + index * 0.25, repeat: Infinity, ease: "easeInOut" }}><Icon /></motion.span>
        <p className="audience-number">0{index + 1}</p><h3>{audience.title}</h3><p className="audience-description">{audience.description}</p><ul>{audience.benefits.map((benefit) => <li key={benefit}>{benefit}</li>)}</ul>
        <JoinJourney defaultRole={audience.role}><Button variant="outline" className="audience-card-cta">{audience.cta}<ArrowUpRight /></Button></JoinJourney>
      </motion.article>; })}
    </motion.div>
  </div></section>;
}
