import { motion, useReducedMotion } from "framer-motion";
import { Lightbulb, MapPinned, Sprout, Users, type LucideIcon } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import experiencesImage from "@/assets/dora-experiences.jpg";
import gatheringImage from "@/assets/dora-gathering.jpg";
import impactImage from "@/assets/dora-impact-world.jpg";
import lisbonImage from "@/assets/dora-lisbon-hero.jpg";

type ProcessStep = {
  number: string;
  title: string;
  shortTitle: string;
  description: string;
  note: string;
  image: string;
  imageAlt: string;
  icon: LucideIcon;
  tone: string;
};

const steps: ProcessStep[] = [
  {
    number: "01",
    title: "Dora goes to a city.",
    shortTitle: "A city",
    description: "A city can invite Dora, a local host can start a stop, or an existing community can build something with us.",
    note: "The spark can start with one person.",
    image: lisbonImage,
    imageAlt: "Friends looking over a city at sunset",
    icon: MapPinned,
    tone: "city",
  },
  {
    number: "02",
    title: "People create experiences.",
    shortTitle: "An experience",
    description: "Not another conference. A dinner, walk, workshop, community project, hike, reading circle, mural, skill-share — or one completely ridiculous idea.",
    note: "Local people decide what feels right.",
    image: experiencesImage,
    imageAlt: "People cooking, gardening, painting and making things together",
    icon: Lightbulb,
    tone: "experience",
  },
  {
    number: "03",
    title: "People show up.",
    shortTitle: "People",
    description: "You don't need to be a member. You don't need a title. You don't need to know anyone beforehand.",
    note: "You just need to want to be there.",
    image: gatheringImage,
    imageAlt: "A group sharing a long outdoor dinner",
    icon: Users,
    tone: "people",
  },
  {
    number: "04",
    title: "Something can stay.",
    shortTitle: "What stays",
    description: "The event ends. The relationship doesn't have to. A dinner can become a ritual, a workshop a mentor, a stranger a friend, and a city a community.",
    note: "That is where the tour really begins.",
    image: impactImage,
    imageAlt: "An illustrated world of people, places and shared activities",
    icon: Sprout,
    tone: "stays",
  },
];

const MotionButton = motion.create(Button);

export function HowItWorksCards() {
  const [activeIndex, setActiveIndex] = useState(0);
  const reduceMotion = useReducedMotion();

  return <>
    <div className="process-deck" role="list" aria-label="How the Dora World Tour works">
      {steps.map((step, index) => {
        const Icon = step.icon;
        const active = index === activeIndex;
        const entranceMotion = reduceMotion ? {} : {
          initial: { opacity: 0, y: 32, rotate: index % 2 ? 2 : -2 },
          whileInView: { opacity: 1, y: 0, rotate: 0 },
        };
        return <MotionButton
          key={step.number}
          type="button"
          variant="ghost"
          role="listitem"
          aria-pressed={active}
          aria-label={`${step.number}. ${step.title}`}
          onClick={() => setActiveIndex(index)}
          layout={!reduceMotion}
          {...entranceMotion}
          viewport={{ once: true, amount: 0.25 }}
          transition={{ delay: reduceMotion ? 0 : index * 0.08, type: "spring", stiffness: 260, damping: 24 }}
          className={`process-card process-card-${step.tone} ${active ? "is-active" : ""}`}
        >
          <span className="process-card-image">
            <img src={step.image} alt={step.imageAlt} loading="lazy" width={900} height={650}/>
            <span className="process-card-stamp"><Icon aria-hidden="true"/><b>{step.number}</b></span>
          </span>
          <span className="process-card-copy">
            <small>{active ? "The story so far" : step.shortTitle}</small>
            <strong>{step.title}</strong>
            <span className="process-card-details">{step.description}</span>
            <em>{step.note}</em>
          </span>
          <span className="process-card-edge" aria-hidden="true">{step.number}</span>
        </MotionButton>;
      })}
    </div>
    <div className="process-path" aria-label="City to something that stays">
      {["City", "Experience", "People", "Connection", "Community", "Something that stays"].map((label, index) => <span key={label} className={index <= activeIndex + 1 ? "is-reached" : ""}>{label}</span>)}
    </div>
  </>;
}