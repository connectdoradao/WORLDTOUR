import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const fieldValueSchema = z.union([
  z.string().trim().max(1000),
  z.array(z.string().trim().max(120)).max(12),
]);

const submissionSchema = z.object({
  formType: z.string().trim().min(1).max(60).regex(/^[a-z0-9-]+$/),
  role: z.string().trim().max(60).optional(),
  fields: z.record(z.string().trim().min(1).max(80), fieldValueSchema).refine(
    (fields) => Object.keys(fields).length <= 30,
    "Too many fields",
  ),
}).superRefine(({ fields }, context) => {
  for (const [key, value] of Object.entries(fields)) {
    if (key.toLowerCase().includes("email") && typeof value === "string" && !z.string().email().max(255).safeParse(value).success) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["fields", key], message: "Invalid email address" });
    }
  }
  for (const key of ["name", "city", "country", "phone", "social"] as const) {
    const value = fields[key];
    if (typeof value === "string" && value.length > 120) {
      context.addIssue({ code: z.ZodIssueCode.custom, path: ["fields", key], message: `${key} is too long` });
    }
  }
});

export const saveFormSubmission = createServerFn({ method: "POST" })
  .inputValidator((data) => submissionSchema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const submittedName = data.fields["name"] ?? data.fields["fullName"] ?? data.fields["pocName"] ?? data.fields["companyName"];
    const submittedEmail = data.fields["email"] ?? data.fields["pocEmail"];
    const name = typeof submittedName === "string" ? submittedName : null;
    const email = typeof submittedEmail === "string" ? submittedEmail : null;
    const city = typeof data.fields["city"] === "string" ? data.fields["city"] : null;
    const { error } = await supabaseAdmin.from("form_submissions").insert({
      form_type: data.formType,
      role: data.role ?? null,
      name,
      email,
      city,
      payload: data.fields,
    });
    if (error) throw new Error("We couldn't save your response. Please try again.");
    return { saved: true };
  });