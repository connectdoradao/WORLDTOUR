import lisbonHero from "@/assets/dora-lisbon-hero.jpg";
import mumbaiHero from "@/assets/dora-mumbai-hero.jpg";
import experiencesImage from "@/assets/dora-experiences.jpg";
import gatheringImage from "@/assets/dora-gathering.jpg";

export const pillars = ["Gather", "Grow", "Give", "Move", "Make"] as const;
export type Pillar = (typeof pillars)[number];
export type CityStatus = "confirmed" | "coming-soon" | "past" | "requested";

export type Experience = {
  id: string; title: string; description: string; pillar: Pillar; day: string;
  time: string; host: string; location: string; price: string; spots: number; image: string;
};

export type City = {
  id: string; slug: string; name: string; country: string; region: string;
  status: CityStatus; heroImage: string; dates?: string; experienceCount?: number;
  requestCount?: number; coordinates: [number, number]; description: string;
  experiences: Experience[];
};

const lisbonExperiences: Experience[] = [
  { id: "sunset-dinner", title: "Sunset Dinner", description: "A phones-away dinner for twelve strangers who won't be strangers by dessert.", pillar: "Gather", day: "Fri, Oct 12", time: "6:00 PM", host: "Sofia Almeida", location: "Alfama", price: "Free", spots: 4, image: gatheringImage },
  { id: "coastal-hike", title: "Coastal Hike", description: "Cliffs, ocean views and a few new friends by the finish line.", pillar: "Move", day: "Sat, Oct 13", time: "8:00 AM", host: "João Martins", location: "Cascais", price: "€15", spots: 8, image: experiencesImage },
  { id: "mural-workshop", title: "Mural Workshop", description: "One wall. No experience needed. Many hands.", pillar: "Make", day: "Sat, Oct 13", time: "3:00 PM", host: "The Bairro", location: "LX Factory", price: "€10", spots: 7, image: experiencesImage },
  { id: "tree-planting", title: "Tree Planting Drive", description: "A greener tomorrow, planted together today.", pillar: "Give", day: "Sun, Oct 14", time: "9:00 AM", host: "Green Lisbon", location: "Monsanto Park", price: "Free", spots: 12, image: experiencesImage },
  { id: "storytelling", title: "Storytelling Night", description: "Real stories. No scripts. Just people.", pillar: "Grow", day: "Sun, Oct 14", time: "7:00 PM", host: "Tiago Costa", location: "The Passenger Hotel", price: "€5", spots: 5, image: gatheringImage },
];

export const cities: City[] = [
  { id: "lisbon", slug: "lisbon", name: "Lisbon", country: "Portugal", region: "Europe", status: "confirmed", heroImage: lisbonHero, dates: "Oct 12–15, 2026", experienceCount: 7, coordinates: [-9.14, 38.72], description: "The world tour lands here for 4 days — dinners, hikes, art, learning, and everything else this city decides it needs more of.", experiences: lisbonExperiences },
  { id: "mumbai", slug: "mumbai", name: "Mumbai", country: "India", region: "Asia", status: "coming-soon", heroImage: mumbaiHero, requestCount: 184, coordinates: [72.88, 19.07], description: "It isn't a stop yet. But it's on the list — and lists move faster with more names on them.", experiences: [] },
  { id: "nairobi", slug: "nairobi", name: "Nairobi", country: "Kenya", region: "Africa", status: "coming-soon", heroImage: experiencesImage, requestCount: 92, coordinates: [36.82, -1.29], description: "Nairobi is gathering its first local circle.", experiences: [] },
  { id: "jakarta", slug: "jakarta", name: "Jakarta", country: "Indonesia", region: "APAC", status: "coming-soon", heroImage: gatheringImage, requestCount: 76, coordinates: [106.85, -6.2], description: "Jakarta is on the list, waiting for its local hosts.", experiences: [] },
  { id: "london", slug: "london", name: "London", country: "United Kingdom", region: "Europe", status: "past", heroImage: gatheringImage, dates: "Jun 3–6, 2026", experienceCount: 9, coordinates: [-0.13, 51.51], description: "Four days, nine rooms, and a city that remembered how to linger.", experiences: lisbonExperiences.slice(0, 3) },
  { id: "bali", slug: "bali", name: "Bali", country: "Indonesia", region: "APAC", status: "past", heroImage: experiencesImage, dates: "Mar 8–11, 2026", experienceCount: 8, coordinates: [115.19, -8.41], description: "We moved, made, planted and ate together.", experiences: lisbonExperiences.slice(1, 5) },
  { id: "new-york", slug: "new-york", name: "New York", country: "USA", region: "Americas", status: "past", heroImage: lisbonHero, dates: "Nov 4–7, 2025", experienceCount: 11, coordinates: [-74, 40.71], description: "The city slowed down for four unexpectedly human days.", experiences: lisbonExperiences.slice(0, 4) },
];

export const hosts = [
  { name: "Sofia Almeida", city: "Lisbon", bio: "I've hosted every Sunday dinner in this city for three years. I still get nervous before every one.", image: gatheringImage },
  { name: "João Martins", city: "Lisbon", bio: "I bring people to the coast because it reminds me what matters.", image: lisbonHero },
  { name: "Rita Santos", city: "Lisbon", bio: "I believe in the power of public art to bring people together.", image: experiencesImage },
];

export const stories = [
  { slug: "i-came-alone", title: "I came alone.", category: "People", city: "Lisbon", date: "Oct 15, 2026", excerpt: "Meera came to the Mumbai dinner knowing nobody. She left with three people she now hikes with every Sunday.", image: gatheringImage },
  { slug: "city-in-24-hours", title: "A city in 24 hours.", category: "Field note", city: "Lisbon", date: "Oct 14, 2026", excerpt: "A day that began on a trail and ended around a table, with no plan for everything between.", image: lisbonHero },
  { slug: "first-dinner", title: "The person who hosted their first dinner.", category: "Host story", city: "London", date: "Jun 6, 2026", excerpt: "From nervous to unstoppable — what happened when twelve strangers walked through one door.", image: gatheringImage },
  { slug: "phones-away", title: "Why 40 people put their phones away.", category: "Moment", city: "Bali", date: "Mar 10, 2026", excerpt: "Sometimes the best ideas are the simplest ones: leave the screen and stay for dessert.", image: experiencesImage },
  { slug: "trail-group", title: "The trail that started a hiking group.", category: "People", city: "Lisbon", date: "Oct 13, 2026", excerpt: "They met at sunrise. They still meet every Saturday.", image: lisbonHero },
];

export const statusLabels: Record<CityStatus, string> = {
  confirmed: "Live now", "coming-soon": "Coming soon", past: "Past", requested: "Requested",
};

export function getCity(slug: string) { return cities.find(city => city.slug === slug); }
export function getStory(slug: string) { return stories.find(story => story.slug === slug); }