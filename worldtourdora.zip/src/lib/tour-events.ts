export type EventCategory = "Gather" | "Grow" | "Give" | "Move" | "Make";
export type TicketType = "free" | "paid" | "sponsored";

export type TourEvent = {
  id: string;
  name: string;
  city: string;
  country: string;
  countryCode: string;
  continent: string;
  category: EventCategory;
  type: string;
  date: string;
  description: string;
  expect: string[];
  ticket: TicketType;
  host: string;
  hostSocials: { label: string; href: string }[];
  eventLink?: string;
  tags: string[];
};

export const ticketLabels: Record<TicketType, string> = {
  free: "Free",
  paid: "Paid",
  sponsored: "Sponsored",
};

export const tourEvents: TourEvent[] = [
  {
    id: "lisbon-long-table",
    name: "Lisbon Long Table",
    city: "Lisbon",
    country: "Portugal",
    countryCode: "pt",
    continent: "Europe",
    category: "Gather",
    type: "Community dinner",
    date: "Oct 12, 2026",
    description: "A phones-away dinner for twelve strangers.",
    expect: [
      "One long table, twelve seats, no phones",
      "A shared meal cooked with local hosts",
      "Conversation prompts that skip the small talk",
    ],
    ticket: "free",
    host: "Host to be confirmed",
    hostSocials: [],
    tags: ["dinner", "phones-away", "strangers", "conversation", "evening", "food"],
  },
  {
    id: "nairobi-adopt-a-patch",
    name: "Nairobi Adopt-a-Patch",
    city: "Nairobi",
    country: "Kenya",
    countryCode: "ke",
    continent: "Africa",
    category: "Give",
    type: "Community care",
    date: "Nov 2026",
    description: "A local green space cared for together.",
    expect: [
      "Hands-on care of a shared green space",
      "Tools and guidance provided on the day",
      "A plan the neighbourhood keeps after we leave",
    ],
    ticket: "free",
    host: "Host to be confirmed",
    hostSocials: [],
    tags: ["outdoors", "green-space", "volunteering", "neighbourhood", "daytime"],
  },
  {
    id: "nyc-sunrise-mission",
    name: "NYC Sunrise Mission",
    city: "New York",
    country: "USA",
    countryCode: "us",
    continent: "North America",
    category: "Move",
    type: "Morning walk",
    date: "Sep 20, 2026",
    description: "Meet early and watch the city wake up.",
    expect: [
      "A pre-dawn meeting point, coffee after",
      "A slow walk through the waking city",
      "A group photo at sunrise, then breakfast",
    ],
    ticket: "sponsored",
    host: "Host to be confirmed",
    hostSocials: [],
    tags: ["sunrise", "walking", "early-morning", "outdoors", "photography"],
  },
  {
    id: "london-idea-playground",
    name: "London Idea Playground",
    city: "London",
    country: "UK",
    countryCode: "gb",
    continent: "Europe",
    category: "Make",
    type: "Making session",
    date: "Past event",
    description: "A room for strange ideas and fast prototypes.",
    expect: [
      "Rapid prototyping with whatever is on the table",
      "Strange ideas welcomed, polished pitches banned",
      "Show-and-tell to close the session",
    ],
    ticket: "paid",
    host: "Host to be confirmed",
    hostSocials: [],
    tags: ["prototyping", "ideas", "indoors", "workshop", "making"],
  },
];

export const eventCategories: EventCategory[] = ["Gather", "Grow", "Give", "Move", "Make"];

export const allEventTags: string[] = Array.from(
  new Set(tourEvents.flatMap((event) => event.tags)),
).sort();
