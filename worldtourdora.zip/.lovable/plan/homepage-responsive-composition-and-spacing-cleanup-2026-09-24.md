# Homepage responsive composition and spacing cleanup

## Goal
Keep the homepage’s desktop visual identity intact at every screen size: the full hero artwork remains visible without cropping, while the logo, message, and actions stay composed as one scene instead of becoming separate stacked blocks.

## Changes
- Rebuild the hero’s responsive rules around one proportional canvas at desktop, tablet, and phone sizes.
- Keep the complete illustration visible with a contained, centered fit and extend its sky-toned surroundings where portrait screens need extra room.
- Position the World Tour ft. Dora logo, handwritten note, supporting copy, and both actions within the hero at every breakpoint, scaling and relocating them only enough to remain readable and overlap-free.
- Preserve the desktop composition while removing the current mobile/tablet rule that places the logo, artwork, and copy in three separate vertical sections.
- Remove “07 · Where Dora is,” “09 — You don’t have to join the same way,” and “15 — Find your way in,” leaving each section’s real heading as the natural introduction.
- Tighten excessive vertical padding and fixed minimum heights across the homepage, especially the five-way cards, map, audience cards, event list, FAQ invitation, and closing action.
- Reduce large internal gaps between headings, descriptions, cards, and actions without making dense content cramped.
- Keep actions inside their content flow, with clean wrapping or full-width stacking on narrow phones, consistent spacing, visible focus states, and restrained lift animations.
- Keep the World Tour ft. Dora logo at its natural aspect ratio in the header, hero, map flags, and footer; adjust only responsive width constraints where needed.

## Verification
- Check the complete homepage at 390×844, 768×1024, 1024×768, and 1440×900.
- Confirm the hero remains a single coherent composition, the full artwork is visible, and text/actions do not cover important artwork or each other.
- Confirm the three requested labels are absent, no section has unexplained empty space, no horizontal overflow appears, and all buttons remain visible and usable.
- Exercise the main hero actions, map controls/popups, audience actions, event actions, FAQ link, and final actions with no browser errors.
