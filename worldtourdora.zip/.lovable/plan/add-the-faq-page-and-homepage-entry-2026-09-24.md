# Add the FAQ page and homepage entry

## What will be built

- Add a new `/faq` page using the site’s warm cream, forest-green, rust, paper-texture, serif, and rounded-control styling.
- Add the supplied introduction and all FAQ copy exactly as written.
- Place a compact FAQ invitation directly after the homepage “What’s happening” section, linking to the full page.
- Add “FAQ” to the footer’s Explore links.

## Interaction

- Store every question in one data array with `category`, `question`, and `answer` fields.
- Derive the five tabs and visible questions from that array; General opens by default.
- Support `/faq#general`, `/faq#attending`, `/faq#hosting`, `/faq#partners-sponsors`, and `/faq#trust-safety`.
- Switch tabs with a short fade/slide and automatically close any open answer.
- Use a single-open accordion with smooth height transitions and a plus icon rotating into a close icon.
- Link the Host page to `/faq#hosting`; link relevant partner entry points to `/faq#partners-sponsors` where they already exist.
- Add an “Ask us directly” action using the site’s existing contact/join flow, avoiding invented contact details.

## Verification

- Check direct hash loading, tab switching, accordion behavior, one-open-at-a-time behavior, and homepage/footer links.
- Verify desktop and mobile layouts, keyboard access, focus states, page metadata, and browser console output.
