# Dora World Tour homepage restructure

## Direction
Keep the current illustrated landing hero completely unchanged. Rework everything beneath it into the exact homepage sequence requested, using Flow Fest’s editorial pacing as a structural reference rather than copying its branding: generous breathing room, bold full-width colour shifts, oversized type, thin outlined details, playful tabs/labels, and simple interactions.

## Homepage structure
1. **Why this exists** — a spacious editorial introduction with one strong statement, supporting copy, and one candid scrapbook image.
2. **What the tour actually is** — retain the Gather / Grow / Give / Move / Make interaction, but give the selector stronger hierarchy and a cleaner full-width stage.
3. **Tour map** — make the living map the visual centre of the section, with clear status keys and a direct route into the full Tour page.
4. **What happens at a stop** — turn the four moments into a bold, numbered journey strip rather than a conventional content grid.
5. **Who it’s for** — three distinct audience panels with large type and immediately visible entry points.
6. **Upcoming cities** — keep only verified prototype city data, displayed as an editorial horizontal rail on smaller screens and a structured three-column composition on wider screens.
7. **Stories from the road** — use overlapping photo/postcard treatments and a clear link to the full archive.
8. **Bring Dora to your city** — one focused closing call-to-action with participant, host, and city-request paths using the existing functional form flow.
9. **Footer / Explore** — retain the full route directory, but simplify the hierarchy and echo the new bold outlined chapter style.

## What will change
- Remove the extra homepage chapters that interrupt the requested sequence; their content remains available on Mission, Impact, Experiences, Host, and other dedicated pages.
- Add reusable homepage section framing for oversized chapter numbers, outlined labels, high-contrast colour bands, and restrained decorative corner tabs inspired by the reference.
- Tighten spacing and section height so each chapter reads as one coherent screen on desktop while remaining naturally scrollable and unclipped on mobile.
- Preserve all existing links, filters, map selection, city cards, story links, and join forms.
- Do not add cities, dates, people, testimonials, attendance figures, or impact claims.

## Responsive and accessibility checks
- Verify the homepage at 390, 768, 1024, and 1440 widths.
- Confirm no horizontal page overflow while preserving intentional horizontal rails.
- Check keyboard focus, pillar switching, map selection, city/story links, and all join-form entry points.
- Confirm the hero remains visually and functionally unchanged.

## Technical notes
- Update the homepage composition in `src/routes/index.tsx` and shared campaign utilities in `src/styles.css`.
- Adjust the shared footer in `src/components/dora-layout.tsx` only where needed for the Explore treatment.
- Reuse the existing data, map, city cards, buttons, and `JoinJourney` form system; no persistence or backend changes.
