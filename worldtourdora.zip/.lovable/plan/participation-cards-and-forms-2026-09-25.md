# Participation cards and forms

## What will change
- Replace the six participation cards with five clear paths: attend, host/bring Dora to a city, community/resources, support, and volunteer.
- Merge “I want to host” with “I want Dora in my city” into one card and one detailed form.
- Merge “I already have a community” with “I have a space, skill or resource” into one card and one form.
- Add a Volunteer card with a dedicated form and ten practical role options.
- Keep the basic “Find your way in” attendee form limited to email, contact number, social link, city, and country.

## Form details
- Host/city form: full name, location, applicant type, organization, current role, community size, previous events, expected attendance, and social links.
- Support form: company and contact-person details, plus selectable support offers: offline space, credits, funding, physical merchandise, media support, and other.
- Volunteer form: identity/contact/location fields, one of ten volunteer roles, and past experience.
- Community/resources form: one combined path with shared contact details and selectable community, space, skill, or resource contributions.

## Validation and storage
- Add clear required fields, input types, length limits, and accessible labels in the form.
- Preserve server-side validation and save every submission through the existing secure form storage.
- Verify card layout and all five form variants on desktop and mobile.
