# Partner showcase section

## Goal
Add one scrapbook-style showcase directly after “There’s more than one way to be part of this” for previous companies, speakers, and communities.

## What will change
- Add a single section with three always-visible category controls: Companies, Speakers, and Communities.
- Automatically rotate the featured category every few seconds so visitors see all three.
- Pause automatic rotation when someone chooses a category, keeping their selection fixed for the rest of the visit.
- Keep the content area accessible with tabs, keyboard navigation, reduced-motion support, and a live but non-disruptive category transition.
- Use honest placeholder states until real partner names, portraits, and logos are supplied; no affiliations will be invented.
- Match the existing paper, stamp, ink, and coral/sun/green visual language without changing the surrounding sections.

## Verification
- Confirm automatic rotation, manual selection lock, keyboard interaction, and reduced-motion behavior.
- Check desktop, tablet, and mobile layouts for clipping, overlap, and horizontal overflow.
