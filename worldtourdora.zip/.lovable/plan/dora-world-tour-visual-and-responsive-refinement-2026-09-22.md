# Dora World Tour — visual and responsive refinement

## Goal
Match the reference hero title treatment more closely, carry its illustrated scrapbook campaign language across every page, and make each major section compose naturally within common screen sizes without clipping or awkward overflow.

## Changes
- Refine the hero title as one compact artwork-like lockup: bold outlined `WORLD TOUR`, centered `ft. DORA` directly beneath it, with reference-matched scale, spacing, tilt, stroke, and shadow at mobile through wide desktop sizes.
- Preserve the existing hero illustration while keeping its airplane, flight path, stamp, Dora, globe, note, copy, and buttons aligned at 390, 768, 1024, and 1440 widths.
- Establish shared campaign section rules for viewport-aware vertical spacing, readable headline sizing, safe rotated scrapbook elements, and predictable image proportions.
- Apply those rules to every homepage section and every interior page, using compact compositions on shorter screens and fuller layouts when space allows. Content will remain complete; nothing will be hidden merely to force an artificial one-screen height.
- Unify colors, typography, paper textures, photo framing, annotations, stamps, borders, and button emphasis around the hero’s sky, sun-yellow, forest-green, coral, cream, and ink palette.
- Strengthen attention hierarchy: primary actions use the strongest campaign treatment, prototype notices remain clear but secondary, and headings/interactive controls stay visually distinct and accessible.
- Keep all current routes, filters, forms, map interactions, city states, stories, and placeholder disclosures unchanged in behavior.

## Technical details
- Centralize responsive section sizing and campaign utility styles in the global design system instead of repeating fragile fixed heights.
- Update shared layout, cards, and page templates so improvements propagate consistently.
- Replace risky absolute positioning or oversized fixed typography where it causes clipping, while retaining intentional scrapbook overlap.
- Maintain semantic color tokens, visible focus states, keyboard support, and reduced-motion behavior.

## Verification
- Visually inspect the homepage and every content route at 390×844, 768×1024, 1024×768, and 1440×900.
- Confirm the hero title composition, airplane/stamp alignment, section framing, navigation, forms, filters, map, dialogs, and no horizontal overflow or console errors.
