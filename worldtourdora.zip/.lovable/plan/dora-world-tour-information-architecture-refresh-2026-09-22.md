# Dora World Tour information architecture refresh

## Goal
Preserve the current illustrated landing hero exactly, then reorganize the rest of the site into a clearer editorial journey inspired by DrawHistory’s strong section rhythm, oversized statements, image-led stories, and varied layouts.

## What will change

### 1. Shared navigation and visual system
- Change “The Tour” in the main navigation to a dedicated `/tour` page while keeping the DoraDAO logo linked to Home.
- Add an Explore-style footer directory for Home, Tour, Cities, Host, Stories, About, Mission, Experiences, and Impact.
- Extend the current scrapbook campaign system with bold editorial bands, numbered chapter labels, oversized linked titles, horizontal story rails, and alternating image/text compositions.
- Keep the existing hero artwork, title lockup, plane, stamp, tagline, and calls to action unchanged.

### 2. Home journey
Reorder and complete the page after the hero:
1. Why this exists
2. What the tour actually is
3. Tour map
4. What happens at a stop
5. Who it’s for
6. Upcoming cities
7. Stories from the road
8. Bring Dora to your city
9. Explore footer

Existing deeper narrative sections will be retained where they strengthen this flow, but consolidated so the page feels intentional rather than like a stack of similar sections.

### 3. Dedicated Tour page
Create `/tour` with:
- Interactive world map
- Live-now stop area
- Upcoming stops
- Past-stop archive entry points
- Clear city-status legend and links to reusable city pages

### 4. Host, Stories, and About
- Host: structure around Why Host, What You Can Host, How It Works, Host Application, and clearly marked placeholder Host Stories.
- Stories: add People, Cities, and Moments filters above the existing postcard archive.
- About: expand the idea behind Dora World Tour using a manifesto-led editorial layout and links to Mission and Impact.

### 5. Verification
- Check all navigation paths and metadata.
- Test map selection, story filtering, application/join actions, and city links.
- Verify key pages at mobile, tablet, laptop, and desktop widths with no horizontal overflow or console errors.

## Technical details
- Add `src/routes/tour.tsx` and update typed TanStack Router links.
- Reuse `WorldMap`, `CityCard`, `PillarGrid`, `JoinJourney`, and the existing mock-data layer.
- Add only presentation and route-composition changes; no database or persistence work.
- Keep all prototype data visibly marked and do not introduce new dates, people, attendance, or impact claims.
